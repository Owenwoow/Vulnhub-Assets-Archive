<?php
/**
 * Author:      Lucas Austin-Howe <lucash@slic.com>
 * Name:        Blue on Blue
 * Date:        December 29, 2005
 * Theme Name:  "Blue on Blue"
 * @copyright &copy; 2005-2007 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: blue_on_blue.php 12127 2007-01-13 20:07:24Z kink $
 * @package squirrelmail
 * @subpackage themes
 */

$color[0]  = '#4c4b83'; // TitleBar
$color[1]  = '#ffffff'; // Not Currently Used
$color[2]  = '#ffffff'; // Warning/Error Messages
$color[3]  = '#19193a'; // Left Bar Background
$color[4]  = '#19193a'; // Normal Background
$color[5]  = '#19193a'; // Table Headers
$color[6]  = '#8a8aaf'; // Text on Left Bar
$color[7]  = '#8a8aaf'; // Normal text
$color[8]  = '#9097bc'; // Links
$color[9]  = '#2d2d3b'; // Darker Version of #0
$color[10] = '#16161d'; // Darker Version of #9
$color[11] = '#ffffff'; // Special Folders color
$color[12] = '#1d1d26'; // Alternate List Item Color (alternates with #4)
$color[13] = '#8a8aaf'; // Single-Quoted text
$color[14] = '#8a8aaf'; // Two or more quotes
$color[15] = '#ffffff'; // Unselectable Folders

?>