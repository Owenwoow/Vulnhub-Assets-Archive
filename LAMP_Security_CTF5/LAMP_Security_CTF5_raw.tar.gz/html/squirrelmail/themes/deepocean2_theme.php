<?php

/**
 * deepocean2_theme.php
 * Name:    Deep Ocean 2
 * Date:    May 23, 2000
 * Comment: Deep Ocean 2 is very blue with a white background.
 *
 * @author M.J. Prinsen
 * @copyright &copy; 2000-2007 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: deepocean2_theme.php 12127 2007-01-13 20:07:24Z kink $
 * @package squirrelmail
 * @subpackage themes
 */

global $color;
$color[0]   = '#6188a9'; // (light gray)     TitleBar
$color[1]   = '#800000'; // (red)
$color[2]   = '#cc0000'; // (light red)      Warning/Error Messages
$color[3]   = '#294763'; // (green-blue)     Left Bar Background
$color[4]   = '#ffffff'; // (white)          Normal Background
$color[5]   = '#597d9d'; // (light yellow)   Table Headers
$color[6]   = '#ffffff'; // (black)          Text on left bar
$color[7]   = '#000000'; // (blue)           Links
$color[8]   = '#000000'; // (black)          Normal text
$color[9]   = '#587b99'; // (mid-gray)       Darker version of #0
$color[10]  = '#496e8b'; // (dark gray)      Darker version of #9
$color[11]  = '#a7c5f3'; // (dark red)       Special Folders color
$color[12]  = '#7092b4';
$color[15]  = '#83a1da'; // (another blue)   Unselectable folders color
?>