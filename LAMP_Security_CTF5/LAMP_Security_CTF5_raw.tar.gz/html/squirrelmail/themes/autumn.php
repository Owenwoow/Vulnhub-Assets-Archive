<?php
/**
 * Author:       Jeremy Landes
 * Date:         December 9, 2005
 * Theme Name:   'Autumn'
 *
 * Theme posted on SquirrelMail tracker #1377525
 * @copyright &copy; 2005-2007 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: autumn.php 12127 2007-01-13 20:07:24Z kink $
 * @package squirrelmail
 * @subpackage themes
 */

global $color;
$color[0]   = '#bb9d45'; // Title bar at the top of the page header
$color[1]   = '#800000'; // Not currently used
$color[2]   = '#cc0000'; // Warning/error messages
$color[3]   = '#71360a'; // Left folder list background color
$color[4]   = '#ffffff'; // Normal background color
$color[5]   = '#c95d02'; // Header of the message index (From, Date, Subject)
$color[6]   = '#ffffff'; // Normal text on the left folder list
$color[7]   = '#2d4900'; // Links in the right frame
$color[8]   = '#000000'; // Normal text
$color[9]   = '#9ca147'; // Darker version of #0
$color[10]  = '#76673e'; // Darker version of #9
$color[11]  = '#c95d02'; // Special folders color (Inbox, Trash, Sent)
$color[12]  = '#ebebeb'; // Alternate color for message list (alters between #4 and this one)
$color[13]  = '#800000'; // Color for single-quoted text ('> text')
$color[14]  = '#ff0000'; // Color for text with more than one quote ('>> text')
$color[15]  = '#ffffff'; // Non-selectable folders in the left frame (defaults to #6)
?>