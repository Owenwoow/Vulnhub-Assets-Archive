<?php

/**
 * dark_grey_theme.php
 *    Name:   Dark Grey
 *    Date:   July 24, 2000
 *
 * @author Justin Miller
 * @copyright &copy; 2000-2007 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: dark_grey_theme.php 12127 2007-01-13 20:07:24Z kink $
 * @package squirrelmail
 * @subpackage themes
 */

global $color;
$color[0]   = '#b2b2b2'; // (gray)           TitleBar
$color[1]   = '#800000'; // (red)
$color[2]   = '#cc0000'; // (light red)      Warning/Error Messages
$color[3]   = '#929292'; // (light gray)     Left Bar Background
$color[4]   = '#ffffff'; // (white)          Normal Background
$color[5]   = '#c0c0c0'; // (lighter grey)   Table Headers
$color[6]   = '#000000'; // (black)          Text on left bar
$color[7]   = '#303030'; // (dark gray)      Links
$color[8]   = '#000000'; // (black)          Normal text
$color[9]   = '#929292'; // (mid-gray)       Darker version of #0
$color[10]  = '#505050'; // (dark gray)      Darker version of #9
$color[11]  = '#770010'; // (dark red)       Special Folders color
$color[15]  = '#440000'; // (darker red)     Unselectable folders

?>