<?php

// ------------------------------------------------------------------

    @ob_start();
    @set_time_limit(0);
//     @error_reporting(2047);
    @session_start();
    error_reporting(E_ALL ^ E_NOTICE);
    // Include the Gallarific functions file
    include(dirname(__FILE__) . "/gfunctions.php");

    // Is there a config file?
    ginstallcheck1();

    // Include the Gallarific config file
    include(dirname(__FILE__) . "/gconfig.php");

    // Has the database been built?
    ginstallcheck2();

    // Create a constant for the path to the selected theme
    define("THEME_PATH", "themes/" . $GLOBALS["gallarific_theme"] . "/");

    // Connect to MySQL
    gmysql();

    // Fix the gallery path
    if(substr($GLOBALS["gallarific_path"], strlen($GLOBALS["gallarific_path"])-1, 1) != "/")
        $GLOBALS["gallarific_path"] .= "/";
    // Include all standard theme files
    include(THEME_PATH . "header.php");

// ------------------------------------------------------------------

?> 
