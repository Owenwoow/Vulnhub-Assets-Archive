<?php

    define("LINK_PHOTO", 5550);
    define("LINK_GALLERY", 5551);

    $GLOBALS["extensions"] = array("image/gif", "image/jpeg", "image/jpg", "image/pjpeg");

    function gmysql() {
        $g_mysql_c = @mysql_connect($GLOBALS["gallarific_mysql_server"],
                                    $GLOBALS["gallarific_mysql_username"],
                                    $GLOBALS["gallarific_mysql_password"])
        or die("A connection to the database couldn't be established: " . mysql_error());

        $g_mysql_d = @mysql_select_db($GLOBALS["gallarific_mysql_database"],
                                      $g_mysql_c)
        or die("The Gallarific database couldn't be opened: " . mysql_error());
    }

    function ginstallcheck1() {
        if(!file_exists(dirname(__FILE__) . "/gconfig.php")) {
            echo "There doesn't seem to be a gconfig.php file. I need this before we can get started. The safest way is to manually create the file using the gconfig-sample.php file to get started.";
            die();
        }
    }

    function ginstallcheck2() {
        if(!$GLOBALS["gallarific_installer_done"]) {
            echo "It doesn't look like you've installed Gallarific yet. Try running <a href='install.php'>install.php</a>.";
            die();
        }
    }

    function ginfo($what) {
        switch($what) {
            case "stylesheet_url": {
                echo "themes/" . $GLOBALS["gallarific_theme"] . "/style.css";
                break;
            }
            case "name": {
                echo $GLOBALS["gallarific_gallery_name"];
                break;
            }
            case "image_path": {
                echo "themes/" . $GLOBALS["gallarific_theme"] . "/images";
                break;
            }
            case "gallarific_path": {
                echo $GLOBALS["gallarific_path"];
                break;
            }
        }
    }
    function gtitle(){            
        $page = $_SERVER['PHP_SELF'];
        $pos = strpos($page, "g.php");
        $title ="";
        if($pos !== false){
            $id = ggalleryidfromurl();    
            $query = "select name from gallarific_galleries where galleryid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                $title = $data['name'];
            }
        }
        $pos = strpos($page, "p.php");
        if($pos !== false){
            $id = gphotoidfromurl();
            $query = "select title from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                $title = $data['title'];
            }
        }
        $pos = strpos($page, "photos.php");
        if($pos !== false){
            $id = escape($_GET['id']);
            $query = "select title from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                $title = $data['title'];
            }
        }
        if($title !="")
            echo $title;
        else
            echo $GLOBALS["gallarific_gallery_name"];
        
    }
    function gdescription(){
        
        $page = $_SERVER['PHP_SELF'];
        $pos = strpos($page, "g.php");
        if($pos !== false){
            $id = ggalleryidfromurl();
            $query = "select description from gallarific_galleries where galleryid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                echo $data['description'];
            }
        }
        
        $pos = strpos($page, "p.php");
        if($pos !== false){
            $id = gphotoidfromurl();    
            $query = "select description from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                echo $data['description'];
            }
        }
        $pos = strpos($page, "photos.php");
        if($pos !== false){
            $id = escape($_GET['id']);
            $query = "select description from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                echo $data['description'];
            }
        }
        
    }
    function gkeywords(){
        $page = $_SERVER['PHP_SELF'];
        $id = gphotoidfromurl();
        $pos = strpos($page, "p.php");
        if($pos !== false){        
            $query = "select tags from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                echo $data['tags'];
            }
        }
        $pos = strpos($page, "photos.php");
        if($pos !== false){
            $id = escape($_GET['id']);
            $query = "select tags from gallarific_photos where photoid = '$id'";
            $result = mysql_query($query);
            if(mysql_num_rows($result)!=0){
                $data = mysql_fetch_array($result);
                echo $data['tags'];
            }
        }
    }

    function ginclude($file) {
        include(THEME_PATH . $file . ".php");
    }

    function grecent($num) {
        $recent = array();
        $query = sprintf("select photoid, filename, title,description, dateuploaded from gallarific_photos where status='1' order by dateuploaded desc limit %d", $num);
        $result = mysql_query($query);

        while($row = mysql_fetch_array($result))
            $recent[] = $row;

        return $recent;
    }

    function glink($id, $type, $sort = "", $tag = "") {
        $link = "";

        if($type == LINK_PHOTO) {
            if($sort == "") {
                //$link = sprintf("photos.php?id=%d", $id);
                $link = sprintf("p.php/%d", $id);
            }
            else
                $link = sprintf("photos.php?id=%d&sort=%s", $id, $sort);

            if($tag != "") {
                $link = sprintf("photos.php?id=%d&sort=%s", $id, $sort);
                $link .= "&tag=" . urlencode($tag);
            }
        }
        else {
            $link = sprintf("g.php/%d", $id);
        }

        return $link;
    }

    function ggalleries() {
        $galleries = array();
        $query = "select galleryid, name, description, parentid from gallarific_galleries where parentid=0 order by sort desc, name asc";
        $result = mysql_query($query);

        while($row = mysql_fetch_array($result)) {
            $galleries[$row["galleryid"]] = $row;
            $galleries[$row["galleryid"]]["subgalleries"] = 0;
        }

        $query = "select galleryid, name, description, parentid from gallarific_galleries where parentid>0 order by sort desc, name asc";
        $result = mysql_query($query);

        while($row = mysql_fetch_array($result)) {
            if(array_key_exists($row["parentid"], $galleries)) {
                $galleries[$row["parentid"]][] = $row;
                $galleries[$row["parentid"]]["subgalleries"]++;
            }
        }
        return $galleries;
    }

    function traverse_index($root, $depth, $sql){
        $row=0;
        while ($acat = mysql_fetch_array($sql)){
            if ($acat['parent'] == $root){
                $j=0;
                echo "<tr>";
                echo "<td valign='top' width='40%'>";
                while ($j<$depth){
                    print "&nbsp;&nbsp;";
                    $j++;
                }
                if($depth>0){
                    print "&nbsp;";
                }
                echo $acat['name'];
                echo "</td></tr>";
                //print $acat['name']."</h2>";
                //hope($acat['id']);        
                
                mysql_data_seek($sql,0); 
                traverse_index($acat['id'], $depth+1,$sql);
            }
            $row++;
            mysql_data_seek($sql,$row);
        }
    }


    function gpopular($num) {
        $recent = array();
        $query = sprintf("select photoid, filename, title, description, views from gallarific_photos where status='1' and views>'0' order by views desc limit %d", $num);
        $result = mysql_query($query);

        while($row = mysql_fetch_array($result))
            $recent[] = $row;

        return $recent;
    }

    function gnav() {
        $nav = array();
        $gallery_id = 0;

        if(is_numeric(strpos(strtolower($_SERVER["PHP_SELF"]), "p.php"))) {
            // We're viewing an individual photo
            $photo_id = (int)@escape($_GET['id']);
            $query = sprintf("select galleryid from gallarific_photos where photoid='%d'", $photo_id);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result))
                $gallery_id = $row["galleryid"];
        }else if(is_numeric(strpos(strtolower($_SERVER["PHP_SELF"]), "photos.php"))) {

            // We're viewing an individual photo
            $photo_id = (int)@escape($_GET['id']);
            $query = sprintf("select galleryid from gallarific_photos where photoid='%d'", $photo_id);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result))
                $gallery_id = $row["galleryid"];
        }else if(is_numeric(strpos(strtolower($_SERVER["PHP_SELF"]), "slideshow.php"))) {

            // We're viewing an individual photo
            $photo_id = (int)@escape($_GET['id']);
            $query = sprintf("select galleryid from gallarific_photos where photoid='%d'", $photo_id);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result))
                $gallery_id = $row["galleryid"];
        }else {
            // We're viewing a photo gallery
            $gallery_id = (int)@escape($_GET['id']);
        }

        //$parent_id = ggalleryidfromurl();
        $sqlx = mysql_query("select * from gallarific_galleries where galleryid=$gallery_id");
        $parents = traverse_reverse($sqlx);
        if(sizeof($parents)!=0)
            ksort($parents);
        return $parents;
    }
    function traverse_reverse($sql){
    global $gall_idsx;
    while ($acat = mysql_fetch_array($sql)){
        if ($acat['galleryid'] != 0){
            $pid = $acat['galleryid'];
            $gall_idsx [$pid]= $acat['name'];
            $sqlx = mysql_query("select * from gallarific_galleries where galleryid={$acat['parentid']}");
            traverse_reverse($sqlx);
        }
    }
    return $gall_idsx;

}

    function gsubgalleries() {
        $galleries = array();

        if(!isset($GLOBALS["gnavmenu"]["sub"])) {
            $gallery_id = (int)@escape($_GET['id']);
            $query = sprintf("select galleryid, name, description, parentid from gallarific_galleries where parentid='%d' order by sort desc, name asc", $gallery_id);
            $result = mysql_query($query);

            while($row = mysql_fetch_array($result)) {
                $galleries[$row["galleryid"]] = $row;
                $galleries[$row["galleryid"]]["subgalleries"] = 0;
            }
        }

        return $galleries;
    }

    function gphotos($sort = "photoid") {
        $photos = array();
        $gallery_id = (int)@escape($_GET['id']);
        $page = (isset($_GET["page"]) ? (int)$_GET["page"] : 1);

        if($page == 1) {
            $end = $GLOBALS["gallarific_photos_per_page"];
            $start = 1;
        }
        else {
            $end = $page * $GLOBALS["gallarific_photos_per_page"];
            $start = $end - ($GLOBALS["gallarific_photos_per_page"]-1);
        }

        $start -= 1;
        $end -= 1;

        if($sort == "")
            $sort = "photoid";

        $real_sort = $sort;

//         switch($sort) {
//             case "dateuploaded": {
//                 $real_sort = "dateuploaded desc";
//                 break;
//             }
//             case "views": {
//                 $real_sort = "views desc";
//                 break;
//             }
//         }

        $query = sprintf("select count(photoid) from gallarific_photos where status='1' and galleryid='%d'", $gallery_id);
        $result = mysql_query($query);
        $num_photos = mysql_result($result, 0, 0);
        $pages = ceil($num_photos / $GLOBALS["gallarific_photos_per_page"]);

        if($num_photos > 0) {
            $query = sprintf("select photoid, filename, dateuploaded, size, views, title, description from gallarific_photos where status='1' and galleryid='%d' order by %s limit %d,%d", $gallery_id, $real_sort, $start, $GLOBALS["gallarific_photos_per_page"]);
            $result = mysql_query($query);

            while($row = mysql_fetch_array($result)) {
                $photos[] = $row;
            }
        }

        return array("page" => $page,
                     "pages" => $pages,
                     "start" => $start,
                     "end" => $end,
                     "num_photos" => $num_photos,
                     "photos" => $photos);
    }

    function gphoto() {
        $id = (int)@escape($_GET['id']);
        
        // Update the view count
        gupdateviewcount($id);

        $query = sprintf("select * from gallarific_photos where photoid='%d'", $id);
/*        echo $query;*/
        $result = mysql_query($query);

        if($row = mysql_fetch_array($result))
            return $row;
    }

    function gupdateviewcount($photo_id) {
        $query = sprintf("update gallarific_photos set views=views+1 where photoid='%d'", $photo_id);
        mysql_query($query);
    }

    function gparsetags($tags) {
        $output = "";
        $tags = explode(",", $tags);

        foreach($tags as $tag) {
            if(trim($tag) != "")
                $output .= sprintf("<a href='tags.php?tag=%s'>%s</a>, ", urlencode(trim($tag)), trim($tag));
        }

        $output = eregi_replace(", $", "", $output);

        if($output == "")
            $output = "None";

        return $output;
    }

    function gcomments() {
        $id = (int)@escape($_GET['id']);
        $comments = array();
        $query = sprintf("select * from gallarific_comments where status='1' and photoid='%d'", $id);
        $result = mysql_query($query);

        while($row = mysql_fetch_array($result))
            $comments[] = $row;

        return $comments;
    }

    function gsavecomment($photo_id, $name, $email, $link, $text) {
        // Is auto-approve comments enabled?
        if($GLOBALS["gallarific_auto_approve_comments"])
            $status = 1;
        else
            $status = 2;

        // Strip HTML from comments
        $text = strip_tags($text);
        $text = str_replace("\r", "<br />", $text);
        $text = str_replace("\n", "", $text);

        $userid = (int)@$_COOKIE["GALLARIFIC_USER_ID"];

        $query = sprintf("insert into gallarific_comments(photoid, name, email, comment, dateadded, status, link, userid) values('%d', '%s', '%s', '%s', '%d', '%d', '%s', '%d')", $photo_id, $name, $email, $text, time(), $status, $link, $userid);

        // Persist comment author details for 3 months
        setcookie("gallarific_gallery_name", $name, time() + (3600*24*100));
        setcookie("gallarific_email", $email, time() + (3600*24*100));
        setcookie("gallarific_link", $link, time() + (3600*24*100));

        if(@mysql_query($query))
            return true;
        else
            return false;
    }

    function gnextprev() {
        $nextprev = array();
        $ids = array();
        $id = (int)@escape($_GET['id']);
        $tag = @escape($_GET["tag"]);
        $sort = @escape($_GET["sort"]);

        if($sort == "")
            $sort = "photoid";

        $real_sort = $sort;

//         switch($sort) {
//             case "dateuploaded": {
//                 $real_sort = "dateuploaded desc";
//                 break;
//             }
//             case "views": {
//                 $real_sort = "views desc";
//                 break;
//             }
//         }

        $query = sprintf("select galleryid from gallarific_photos where photoid='%d'", $id);
        $result = mysql_query($query);

        if($row = mysql_fetch_array($result)) {
            $gallery_id = $row["galleryid"];

            if($tag == "")
                $query = sprintf("select photoid from gallarific_photos where galleryid='%d' order by %s", $gallery_id, $real_sort);
            else
                $query = sprintf("select photoid from gallarific_photos where tags like '%%%s%%' order by %s", $tag, $real_sort);


            $result = mysql_query($query);

            while($row = mysql_fetch_array($result))
                $ids[] = $row["photoid"];
            
            if(sizeof($ids) > 0) {
                for($i = 0; $i < sizeof($ids); $i++) {
                    if($ids[$i] == $id) {
                        if($i > 0)
                            $nextprev["prev"] = $ids[$i-1];

                        if($i < sizeof($ids)-1)
                            $nextprev["next"] = $ids[$i+1];

                        break;
                    }
                }
            }
        }

        return $nextprev;
    }

    function gphotosbytag($sort = "photoid") {
        $photos = array();
        $tag = escape($_GET["tag"]);
        $page = (isset($_GET["page"]) ? (int)$_GET["page"] : 1);

        if($page == 1) {
            $end = $GLOBALS["gallarific_photos_per_page"];
            $start = 1;
        }
        else {
            $end = $page * $GLOBALS["gallarific_photos_per_page"];
            $start = $end - ($GLOBALS["gallarific_photos_per_page"]-1);
        }

        $start -= 1;
        $end -= 1;

        if($sort == "")
            $sort = "photoid";

        $real_sort = $sort;

//         switch($sort) {
//             case "dateuploaded": {
//                 $real_sort = "dateuploaded desc";
//                 break;
//             }
//             case "views": {
//                 $real_sort = "views desc";
//                 break;
//             }
//         }

        $query = sprintf("select count(photoid) from gallarific_photos where status='1' and tags like '%%%s%%'", $tag);
        $result = mysql_query($query);
        $num_photos = mysql_result($result, 0, 0);
        $pages = ceil($num_photos / $GLOBALS["gallarific_photos_per_page"]);

        if($num_photos > 0) {
            $query = sprintf("select photoid, filename, dateuploaded, size, views, title, description from gallarific_photos where status='1' and tags like '%%%s%%' order by %s limit %d,%d", $tag, $real_sort, $start, $GLOBALS["gallarific_photos_per_page"]);
            $result = mysql_query($query);

            while($row = mysql_fetch_array($result)) {
                $photos[] = $row;
            }
        }

        return array("page" => $page,
                     "pages" => $pages,
                     "start" => $start,
                     "end" => $end,
                     "num_photos" => $num_photos,
                     "photos" => $photos);
    }

    function gsaveslideshowstate() {
        // Store the first image in the slideshow so when the user
        // clicks stop or we're on the last photo we can take
        // them back to that photo
        if(isset($_GET["first"])) {
            $_SESSION["gallarific_slideshow_first"] = (int)$_GET["first"];

            if(isset($_GET["tag"])) {
                $_SESSION["gallarific_slideshow_first"] .= "&tag=" . escape($_GET["tag"]);
                $_SESSION["gallarific_slideshow_tag"] = escape($_GET["tag"]);
            }
        }
    }

    function gregisteruser(&$error, &$user_id) {
        $username = escape($_POST["username"]);
        $password = escape($_POST["password"]);
        $email = escape($_POST["email"]);
        $firstname = escape($_POST["firstname"]);
        $lastname = escape($_POST["lastname"]);
        $website = escape($_POST["website"]);
        $photo = array();
        $photo_file = "";
        $join_code = GenerateJoinCode();
        $GLOBALS["join_code"] = $join_code;

        if($website == "http://")
            $website = "";

        if($_FILES["photo"]["size"] > 0) {
            $photo = $_FILES["photo"];
            $mime = strtolower($photo["type"]);
            $newname = GenerateFilename();
            $newWidth = 0;
            $newHeight = 0;

            if($mime == "image/gif")
                $newname .= ".gif";
            else
                $newname .= ".jpg";

            $dest = "photos/user_" . $newname;
            $photo_file = $newname;

            if(in_array($mime, $GLOBALS["extensions"])) {
                if(@move_uploaded_file($photo["tmp_name"], $dest)) {
                    // Try to create a thumbnail image
                    if(function_exists("gd_info")) {
                        // Create a thumbnail image
                        $dimensions = getimagesize($dest);
                        $width = $dimensions[0];
                        $height = $dimensions[1];

                        // First check the boundaries
                        if($width > $GLOBALS["gallarific_userimage_width"] || $height > $GLOBALS["gallarific_userimage_height"]) {
                            if($mime == "image/gif")
                                $sourceImage = imageCreateFromGif($dest);
                            else
                                $sourceImage = imageCreateFromJpeg($dest);

                            if ($width > $height) {
                                $thumbWidth = $GLOBALS["gallarific_userimage_width"];
                                $thumbHeight = $height*($GLOBALS["gallarific_userimage_height"]/$width);
                            }
                            if ($width < $height) {
                                $thumbWidth = $width*($GLOBALS["gallarific_userimage_width"]/$height);
                                $thumbHeight = $GLOBALS["gallarific_userimage_height"];
                            }
                            if ($width == $height) {
                                $thumbWidth = $GLOBALS["gallarific_userimage_width"];
                                $thumbHeight = $GLOBALS["gallarific_userimage_height"];
                            }

                            // Remove any decimal places
                            settype($thumbWidth, "integer");
                            settype($thumbHeight, "integer");

                            $destImage = ImageCreateTrueColor($thumbWidth, $thumbHeight);
                            imagecopyresampled($destImage, $sourceImage, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);

                            if($mime == "image/gif")
                                imagegif($destImage, $dest); 
                            else
                                imagejpeg($destImage, $dest); 

                            imagedestroy($destImage);
                            imagedestroy($sourceImage);
                        }
                        else {
                            // The image is less then the thumbnail size, just copy it
                            if(!@copy($dest, $dest)) {
                                $photo_file = "";
                            }
                        }
                    }
                    else {
                        if(!@copy($dest, $dest)) {
                            $photo_file = "";
                        }
                    }
                    // End thumbnail creation
                }
            }
        }

        // Check if the username is taken
        $query = sprintf("select count(userid) from gallarific_users where username='%s'", $username);
        $result = mysql_query($query);
        $row = mysql_fetch_row($result);

        if($row[0] == 0) {
            // Username is available
            $query = sprintf("insert into gallarific_users(username, password, usertype, firstname, lastname, email, datejoined, website, issuperuser, photo, joincode) values('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')", $username, $password, "normaluser", $firstname, $lastname, $email, time(), $website, 0, $photo_file, $join_code);

            if(@mysql_query($query)) {
                $user_id = mysql_insert_id();
                return true;
            }
            else {
                $error = mysql_error();
                return false;
            }
        }
        else {
            // Username is taken
            $error = sprintf("The username '%s' is already taken.", $username);
            return false;
        }
    }

    function GenerateFilename() {
        $range1 = range('a', 'z');
        $range2 = range('0', '9');
        $filename = "";
        srand();

        for($i = 0; $i < 10; $i++) {
            if(rand(1, 2) == 1)
                $filename .= $range1[rand(0, 25)];
            else
                $filename .= $range2[rand(0, 9)];
        }

        return $filename;
    }

    function GenerateJoinCode() {
        $range = range('0', '9');
        $code = "";
        srand();

        for($i = 0; $i < rand(7,10); $i++) {
            $code .= $range[rand(0, 9)];
        }

        return $code;
    }

    function gsendregisterverifyemail($user_id) {
        // Get user details from the database
        $query = sprintf("select * from gallarific_users where userid='%d'", $user_id);
        $result = mysql_query($query);

        if($row = mysql_fetch_array($result)) {
            $confirm_url = sprintf("http://%s%s?a=act&u=%d&i=%s", $_SERVER["HTTP_HOST"], $_SERVER["PHP_SELF"], $user_id, $row["joincode"]);
            $title = sprintf("Action required to activate account for %s", $GLOBALS["gallarific_gallery_name"]);
            $message = sprintf("Dear %s,\r\n\r\nThank you for registering at %s. Before we can activate your account one last step must be taken to complete your registration.\r\n\r\nPlease note - you must complete this last step to become a registered member. You will only need to visit this url once to activate your account.\r\n\r\nTo complete your registration, please visit this url:\r\n%s\r\n\r\n<a href=\"%s\">America Online Users Please Visit Here to be Activated</a>\r\n\rAll the best,\r\n%s", $row["username"], $GLOBALS["gallarific_gallery_name"], $confirm_url, $confirm_url, $GLOBALS["gallarific_gallery_name"]);

            if(@mail($row["email"], $title, $message, "From: " . $GLOBALS["gallarific_gallery_name"] . " <" . $GLOBALS["gallarific_email"] . ">"))
                return true;
            else
                return false;
        }
        else {
            return false;
        }
    }

    function gconfirmuser(&$error) {
        if(isset($_GET["a"]) && isset($_GET["u"]) && isset($_GET["i"])) {
            $user_id = (int)$_GET["u"];
            $join_code = $_GET["i"];
            $query = sprintf("select username from gallarific_users where userid='%d' and joincode='%s'", $user_id, $join_code);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result)) {
                // Reset the join code to nothing to confirm their registration
                $user_name = $row["username"];
                $query = sprintf("update gallarific_users set joincode='' where userid='%d'", $user_id);
                @mysql_query($query);
                return true;
            }
            else {
                $error = "Your account details are invalid. Please double check the confirm link in your email. You may need to copy it into your browsers address bar instead of clicking it.";
                return false;
                }
        }
        else {
            $error = "Your account details are invalid. Please double check the confirm link in your email. You may need to copy it into your browsers address bar instead of clicking it.";
            return false;
        }
    }

    function glogin(&$error, &$user_name) {
        if(isset($_POST["gusername"]) && isset($_POST["gpassword"])) {
            $username = escape($_POST["gusername"]);
            $password = escape($_POST["gpassword"]);
            $query = sprintf("select * from gallarific_users where username='%s' and password='%s'", $username, $password);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result)) {
                if($row["joincode"] == "") {
                    // Success!
                    $user_name = $row["username"];
                    setcookie("GALLARIFIC_USER_ID", $row["userid"], time() + (3600*24*500));
                    setcookie("GALLARIFIC_USERNAME", $row["username"], time() + (3600*24*500));
                    setcookie("GALLARIFIC_HASH", md5($row["userid"] . "___" . $row["username"]), time() + (3600*24*500));
                    return true;
                }
                else {
                    // The user hasn't confirmed their registration yet
                    gsendregisterverifyemail($row["userid"]);
                    $error = sprintf("You haven't confirmed your registration yet. We've resent the confirmation email to %s so please check your inbox now. If you can't see the confirmation email, check your junkmail folder too.", $row["email"]);
                    return false;
                }
            }
            else {
                $error = "Your username or password is incorrect. Please login again.";
                return false;
            }
        }
        else {
            $error = "Your username or password is incorrect. Please login again.";
            return false;
        }
    }

    function gisloggedin() {
        if(@$_COOKIE["GALLARIFIC_USER_ID"] != "" && @$_COOKIE["GALLARIFIC_USERNAME"] != "" && @$_COOKIE["GALLARIFIC_HASH"] != "") {
            if($_COOKIE["GALLARIFIC_HASH"] == md5(sprintf("%s___%s", $_COOKIE["GALLARIFIC_USER_ID"], $_COOKIE["GALLARIFIC_USERNAME"]))) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }

    function glogout() {
        setcookie("GALLARIFIC_USERNAME", "", time() - (3600*24*500));
        setcookie("GALLARIFIC_USER_ID", "", time() - (3600*24*500));
        setcookie("GALLARIFIC_HASH", "", time() - (3600*24*500));
    }

    function guserdetails() {
        $user = array("name" => "",
                      "email" => "",
                      "website" => ""
        );

        if(isset($_COOKIE["GALLARIFIC_USER_ID"])) {
            $query = sprintf("select * from gallarific_users where userid='%d'", $_COOKIE["GALLARIFIC_USER_ID"]);
            $result = mysql_query($query);

            if($row = mysql_fetch_array($result)) {
                $user = $row;
                $user["name"] = sprintf("%s %s", $row["firstname"], $row["lastname"]);
                $user["name"] = trim($user["name"]);
                $user["email"] = $row["email"];
                $user["website"] = $row["website"];
            }
        }

        return $user;
    }

    function guserphoto($user_id) {
        $pquery = sprintf("select photo from gallarific_users where userid='%d'", $user_id);
        $presult = mysql_query($pquery);

        if($prow = mysql_fetch_array($presult))
            return $prow["photo"];
    }

    function gprofilesave(&$error) {
        $username = $_COOKIE["GALLARIFIC_USERNAME"];
        $user_id = $_COOKIE["GALLARIFIC_USER_ID"];
        $password = escape($_POST["password"]);
        $email = escape($_POST["email"]);
        $firstname = escape($_POST["firstname"]);
        $lastname = escape($_POST["lastname"]);
        $website = escape($_POST["website"]);
        $photo = array();
        $photo_file = "";

        if($website == "http://")
            $website = "";

        if($_FILES["photo"]["size"] > 0) {
            $photo = $_FILES["photo"];
            $mime = strtolower($photo["type"]);
            $newname = GenerateFilename();
            $newWidth = 0;
            $newHeight = 0;

            if($mime == "image/gif")
                $newname .= ".gif";
            else
                $newname .= ".jpg";

            $dest = "photos/user_" . $newname;
            $photo_file = $newname;

            if(in_array($mime, $GLOBALS["extensions"])) {
                if(@move_uploaded_file($photo["tmp_name"], $dest)) {
                    // Try to create a thumbnail image
                    if(function_exists("gd_info")) {
                        // Create a thumbnail image
                        $dimensions = getimagesize($dest);
                        $width = $dimensions[0];
                        $height = $dimensions[1];

                        // First check the boundaries
                        if($width > $GLOBALS["gallarific_userimage_width"] || $height > $GLOBALS["gallarific_userimage_height"]) {
                            if($mime == "image/gif")
                                $sourceImage = imageCreateFromGif($dest);
                            else
                                $sourceImage = imageCreateFromJpeg($dest);

                            if ($width > $height) {
                                $thumbWidth = $GLOBALS["gallarific_userimage_width"];
                                $thumbHeight = $height*($GLOBALS["gallarific_userimage_height"]/$width);
                            }
                            if ($width < $height) {
                                $thumbWidth = $width*($GLOBALS["gallarific_userimage_width"]/$height);
                                $thumbHeight = $GLOBALS["gallarific_userimage_height"];
                            }
                            if ($width == $height) {
                                $thumbWidth = $GLOBALS["gallarific_userimage_width"];
                                $thumbHeight = $GLOBALS["gallarific_userimage_height"];
                            }

                            // Remove any decimal places
                            settype($thumbWidth, "integer");
                            settype($thumbHeight, "integer");

                            $destImage = ImageCreateTrueColor($thumbWidth, $thumbHeight);
                            imagecopyresampled($destImage, $sourceImage, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);

                            if($mime == "image/gif")
                                imagegif($destImage, $dest); 
                            else
                                imagejpeg($destImage, $dest); 

                            imagedestroy($destImage);
                            imagedestroy($sourceImage);
                        }
                        else {
                            // The image is less then the thumbnail size, just copy it
                            if(!@copy($dest, $dest)) {
                                $photo_file = "";
                            }
                        }
                    }
                    else {
                        if(!@copy($dest, $dest)) {
                            $photo_file = "";
                        }
                    }
                    // End thumbnail creation
                }
            }
        }

        // Username is available
        if($photo_file == "")
            $query = sprintf("update gallarific_users set password='%s', firstname='%s', lastname='%s', email='%s', website='%s' where userid='%d'", $password, $firstname, $lastname, $email, $website, $user_id);
        else
            $query = sprintf("update gallarific_users set password='%s', firstname='%s', lastname='%s', email='%s', website='%s', photo='%s' where userid='%d'", $password, $firstname, $lastname, $email, $website, $photo_file, $user_id);

        if(@mysql_query($query)) {
            return true;
        }
        else {
            $error = mysql_error();
            return false;
        }
    }

    function gsearchresults() {
        $results = array();
        $query = escape($_GET["query"]);
        $field = $_GET["field"];
        $when = $_GET["when"];
        $date = $_GET["date"];
        $date_filter = "";
        $when_filter = "";

        if($field == "desc")
            $field = "description";

        if($field != "description" && $field != "tags")
            $field = "description";

        if($date != "") {
            $date_vals = explode("/", $date);

            if(sizeof($date_vals) == 3) {
                $date_stamp = mktime(0, 0, 0, $date_vals[0], $date_vals[1], $date_vals[2]);

                switch($when) {
                    case "before": {
                        $date_filter = sprintf("and dateuploaded < '%s'", $date_stamp);
                        break;
                    }
                    case "on": {
                        $date_filter = sprintf("and dateuploaded >= '%s' and dateuploaded <= '%s'", $date_stamp, ((int)$date_stamp)+(3600*24));
                        break;
                    }
                    case "after": {
                        $date_filter = sprintf("and dateuploaded > '%s'", ((int)$date_stamp)+(3600*24));
                        break;
                    }
                }
            }
        }

        $recent = array();
        $squery = sprintf("select photoid, filename, title, description, dateuploaded from gallarific_photos where status='1' and %s like '%%%s%%' %s", $field, $query, $date_filter);
//         echo $squery;
        $result = mysql_query($squery);

        while($row = mysql_fetch_array($result))
            $results[] = $row;

        return $results;
    }

    function gphotoidfromurl() {
        // Get the photo id from the URL
        $id = 0;
        $matches = array();

        eregi("p.php/([0-9]{1,})", $_SERVER["REQUEST_URI"], $matches);

        if(sizeof($matches) > 1)
            $id = (int)$matches[1];

        return $id;
    }

    function ggalleryidfromurl() {
        // Get the photo id from the URL
        $id = 0;
        $matches = array();

        eregi("g.php/([0-9]{1,})", $_SERVER["REQUEST_URI"], $matches);

        if(sizeof($matches) > 1)
            $id = (int)$matches[1];

        return $id;
    }
    function escape($string){
        if(get_magic_quotes_gpc()){
            $string = htmlentities($string);
        }else{
            $string = mysql_real_escape_string($string);
            $string = htmlentities($string);
        }
        return $string;
    }
?>
