<!-- links: output quick links for gallery -->
   <tr>
    <td colspan="2" class="text count">
     <center>
<table>
<tr><td nowrap="nowrap" valign="top" align="left" height="32">
      <strong>Quick Links:</strong>&nbsp;&nbsp;&nbsp;
      <a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;
      <a href="recent.php">Recent Photos</a>&nbsp;&nbsp;&nbsp;
     <!--  <a href="gadmin">Admin</a>&nbsp;&nbsp; -->
</td></tr></table>
</form>
     </center>
    </td>
   </tr>
<!-- links_end --> 
