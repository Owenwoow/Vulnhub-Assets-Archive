<?php

	// Call the Gallarific logout function
	glogout();

?>
  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="heading padlr">Account Logout</td>
			</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%" class="pad">
					<div class="help">
						<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" />
						You have been logged out successfully. You are being taken back to the gallery...
						<script>window.setTimeout("document.location.href='index.php';", 3000);</script>
					</div>
				</td>
			</tr>
		</table>
	</td>
   </tr>
  </table>
