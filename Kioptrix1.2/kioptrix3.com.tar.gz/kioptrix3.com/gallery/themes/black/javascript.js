function ge(id) {
	return document.getElementById(id);
}

function gallarific_sort(field, gallery_id,path) {
	document.location.href = path+"gallery.php?id="+gallery_id+"&sort="+field+"#photos";
}
function gallarific_sort_tag(field, tag) {
	document.location.href = "tags.php?tag="+tag+"&sort="+field+"#photos";
}

function loginFormCheck() {
	var gu = ge("gusername");
	var gp = ge("gpassword");

	if(gu.value == "") {
		alert("You forgot to enter your username.");
		gu.focus();
		return false;
	}

	if(gp.value == "") {
		alert("You forgot to enter your password.");
		gp.focus();
		return false;
	}

	return true;
}

function commentFormCheck() {
	var cn = ge("comment_name");
	var ce = ge("comment_email");
	var cl = ge("comment_link");
	var ct = ge("comment_text");

	if(cn.value == "") {
		alert("You forgot to enter your name.");
		cn.focus();
		return false;
	}

	if(ce.value.indexOf("@") == -1 || ce.value.indexOf(".") == -1) {
		alert("You must enter a valid email address.");
		ce.focus();
		ce.select();
		return false;
	}

	if(cl.value != "" && cl.value.indexOf("http://") != 0) {
		alert("Your website must begin with 'http://'");
		cl.focus();
		cl.select();
		return false;
	}

	if(ct.value == "") {
		alert("You forgot to enter your comment.");
		ct.focus();
		return false;
	}

	return true;
}

function gallarific_slideshow(pause, next, tag) {
	window.setTimeout("gallarific_slideshow_do(" + next + ", '" + tag + "');", pause*1000);
}

function gallarific_slideshow_do(next, tag) {
	if(next == 0) {
		alert("Slideshow Complete!");
	}
	else {
		if(tag == "")
			document.location.href = "slideshow.php?id=" + next;
		else
			document.location.href = "slideshow.php?id=" + next + "&tag=" + tag;
	}
}

function gallarific_slideshow_setpause(pause, photo_id, tag) {
	if(tag == "")
		document.location.href = "slideshow.php?pause=" + pause + "&id=" + photo_id;
	else
		document.location.href = "slideshow.php?pause=" + pause + "&id=" + photo_id + "&tag=" + tag;
}

function gallarific_check_register() {
	var un = ge("username");
	var pw = ge("password");
	var pwc = ge("passwordc");
	var em = ge("email");
	var fn = ge("firstname");
	var ws = ge("website");
	var ph = ge("photo");

	if(un.value == "") {
		alert("You must enter a username.");
		un.focus();
		return false;
	}

	if(pw.value == "") {
		alert("You must enter a password.");
		pw.focus();
		return false;
	}

	if(pw.value != pwc.value) {
		alert("Your passwords don't match.");
		pwc.focus();
		pwc.select();
		return false;
	}

	if(em.value.indexOf("@") == -1 || em.value.indexOf(".") == -1) {
		alert("You must enter a valid email address.");
		em.focus();
		em.select();
		return false;
	}

	if(fn.value == "") {
		alert("You must enter your first name.");
		fn.focus();
		return false;
	}

	if(ws.value != "" && ws.value.indexOf("http://") != 0) {
		alert("Your web site must start with 'http://'");
		ws.focus();
		ws.select();
		return false;
	}

	if(ph.value != "") {
		pht = ph.value.toLowerCase();
		dat = pht.split(".");
		ext = dat[dat.length-1];
		
		if(ext != "gif" && ext != "jpg" && ext != "jpeg") {
			alert("Your photo must be a GIF or JPEG image.");
			ph.focus();
			ph.select();
			return false;
		}
	}

	return true;
}

function gallarific_check_profile() {
	var pw = ge("password");
	var pwc = ge("passwordc");
	var em = ge("email");
	var fn = ge("firstname");
	var ws = ge("website");
	var ph = ge("photo");

	if(pw.value == "") {
		alert("You must enter a password.");
		pw.focus();
		return false;
	}

	if(pw.value != pwc.value) {
		alert("Your passwords don't match.");
		pwc.focus();
		pwc.select();
		return false;
	}

	if(em.value.indexOf("@") == -1 || em.value.indexOf(".") == -1) {
		alert("You must enter a valid email address.");
		em.focus();
		em.select();
		return false;
	}

	if(fn.value == "") {
		alert("You must enter your first name.");
		fn.focus();
		return false;
	}

	if(ws.value != "" && ws.value.indexOf("http://") != 0) {
		alert("Your web site must start with 'http://'");
		ws.focus();
		ws.select();
		return false;
	}

	if(ph.value != "") {
		pht = ph.value.toLowerCase();
		dat = pht.split(".");
		ext = dat[dat.length-1];
		
		if(ext != "gif" && ext != "jpg" && ext != "jpeg") {
			alert("Your photo must be a GIF or JPEG image.");
			ph.focus();
			ph.select();
			return false;
		}
	}

	return true;
}

function searchFormCheck() {
	qu = ge("query");
	dt = ge("date");

	if(qu.value.length < 3) {
		alert("You must enter a search query of at 3 characters or more.");
		qu.focus();
		return false;
	}

	if(dt.value != "") {
		var da = dt.value.split("/");

		if(da.length == 3) {
			var isOK = true;

			if(da[0].length != 2)
				isOK = false;

			if(da[1].length != 2)
				isOK = false;

			if(da[2].length != 4)
				isOK = false;

			if(!isOK) {
				alert("You must enter a valid date in the format of mm/dd/yyyy.");
				dt.focus();
				dt.select();
				return false;
			}
		}
		else {
			alert("You must enter a valid date in the format of mm/dd/yyyy.");
			dt.focus();
			dt.select();
			return false;
		}
	}
}
