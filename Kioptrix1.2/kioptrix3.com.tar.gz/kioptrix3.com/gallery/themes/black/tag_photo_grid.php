<?php

	$tag = escape($_GET["tag"]);
	$sort = escape($_GET["sort"]);
	$photos = gphotosbytag($sort);
	$i = 0;
	$nav = "";

	if($photos["num_photos"] > 0) {
		$end = $photos["end"]+1;

		if($end > $photos["num_photos"])
			$end = $photos["num_photos"];

		$heading = sprintf("Displaying Photos %d to %d of %d for tag \"%s\"", $photos["start"]+1, $end, $photos["num_photos"], $tag);
	}
	else
		$heading = sprintf("Photos Tagged \"%s\"", $tag);

	echo "<!-- gallery_photo_grid: output 4x1 rows containing photos in this gallery -->";
	echo "<a name='photos'></a>";
	echo "<tr>";
	echo " <td colspan=\"2\" class=\"heading\">";
	echo $heading;
	echo " </td>";
	echo "</tr>";
	echo "<tr>";

	if(sizeof($photos["photos"]) > 0) {
		echo " <td colspan=\"2\">";
		echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
		echo " <tr>";

		foreach($photos["photos"] as $photo) {
			$i++;
			$description = "<br />";

			if($photo["description"] != "") {

				if(strlen($photo["description"]) < 50)
					$description .= $photo["description"];
				else
					$description .= substr($photo["description"], 0, 50) . "...";
			}
			$title = "";
			if($photo["title"] != "") {
				if(strlen($photo["title"]) < 50)
					$title = $photo["title"];
				else
					$title = substr($photo["title"], 0, 50) . "...";

				$title .= "<br />";
			}else{
				$title .= "<br />";
			}

			$ptitle = sprintf("%s - %s Views, Uploaded %s, %d KB", $photo["filename"], number_format($photo["views"]), date($GLOBALS["gallarific_date_format"], $photo["dateuploaded"]), ceil($photo["size"]/1024));

			printf("<td width=\"25%%\" class=\"grid border\" valign=\"top\"><a href=\"%s\" title=\"%s\">%s<img src=\"photos/thumb_%s\" border=\"0\" />%s</a></td>", glink($photo["photoid"], LINK_PHOTO, $sort, $tag), $ptitle,$title, $photo["filename"], $description);

			if($i == 4) {
				echo "</tr>";
				echo "<tr>";
				$i = 0;
			}
		}

		for($j = $i; $j < 4; $j++) {
			$k = $j;
			echo "<td>&nbsp;</td>";

			if($k == 4)
				$k = 0;
		}

		echo " </tr>";
		echo "</table>";

	}
	else {
		echo " <td class=\"pad\" colspan=\"2\">";
		echo "No photos have been uploaded. <a href='javascript:history.go(-1)'>Go back.</a>";
	}

	echo " </td>";
	echo "</tr>";

	if($photos["num_photos"] > 0) {
		echo "<tr>";
		echo " <td colspan=\"2\" class=\"heading\" align=\"center\">";
		echo "  <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
		echo "   <tr>";
		echo "    <td width=\"20%\">";
		printf("     <select onchange=\"gallarific_sort_tag(this.options[this.selectedIndex].value, '%s')\" name=\"sort\" id=\"sort\">", $tag);
		echo "      <option value=\"\">- Sorting Options -</option>";

		if($sort == "photoid")
			$selected = "SELECTED";
		else
			$selected = "";

		printf("      <option %s value='photoid'>Photo Id</option>", $selected);

		if($sort == "filename")
			$selected = "SELECTED";
		else
			$selected = "";
		
		printf("      <option %s value='filename'>File Name</option>", $selected);

		if($sort == "size")
			$selected = "SELECTED";
		else
			$selected = "";
		
		printf("      <option %s value='size'>File Size</option>", $selected);

		if($sort == "dateuploaded")
			$selected = "SELECTED";
		else
			$selected = "";
		
		printf("      <option %s value='dateuploaded'>Date Uploaded</option>", $selected);

		if($sort == "views")
			$selected = "SELECTED";
		else
			$selected = "";
		
		printf("      <option %s value='views'>Views</option>", $selected);

		echo "     </select>";
		echo "    </td>";
		echo "    <td width=\"80%\" align=\"right\" class=\"padlr\">Pages: ";

		if($photos["page"] > 1) {
			$nav .= sprintf(" <a href='tags.php?page=%d&sort=%s&tag=%s#photos'>&laquo; Previous</a> |", $photos["page"]-1, $sort, $tag);
		}
		
		for($i = 1; $i <= $photos["pages"]; $i++) {
			if($i == $photos["page"])
				$nav .= sprintf(" %d |", $i);
			else
				$nav .= sprintf(" <a href='tags.php?page=%d&sort=%s&tag=%s#photos'>%d</a> |", $i, $sort, $tag, $i);
		}

		if($photos["page"] < $photos["pages"]) {
			$nav .= sprintf(" <a href='tags.php?page=%d&sort=%s&tag=%s#photos'>Next &raquo;</a>", $photos["page"]+1, $sort, $tag);
		}

		$nav = eregi_replace("\|$", "", $nav);
		echo $nav;

		echo "    </td>";
		echo "   </tr>";
		echo "  </table>";

		echo " </td>";
		echo "</tr>";
	}

	echo "<!-- gallery_photo_grid_end -->";

?>
