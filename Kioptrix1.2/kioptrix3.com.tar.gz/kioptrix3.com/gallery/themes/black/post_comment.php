<?php

	// Call the gsavecomment function to add the comment to the database
	$photo_id = $_POST["comment_photo"];
	$name = escape($_POST["comment_name"]);
	$email = escape($_POST["comment_email"]);
	$link = escape($_POST["comment_link"]);
	$text = escape($_POST["comment_text"]);

	if(gsavecomment($photo_id, $name, $email, $link, $text)) {
		ob_end_clean();
		header(sprintf("Location: photos.php?id=%d&comment_posted=true#comments", $photo_id));
		die();
	}

?>