<?php

	if(gisloggedin()) {
		$error = "";
		$is_saved = gprofilesave($error);

		if(!$is_saved) {
			$GLOBALS["register_error"] = $error;
			ginclude('profile_form');
		}
		else {
		?>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td class="heading padlr">
						Profile Updated
					</td>
				</tr>
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="100%" class="pad">
						<div class="help">
							<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" />
							Your profile has been updated. <a href="index.php">Click here</a> to return to the gallery.
						</div>
					</td>
				</tr>
			</table>
		<?php
		}
	}
	else { ?>
		<script>document.location.href="index.php?session_expired=true";</script>
<?php } ?>
