<?php
//Start script timer
$starttime = explode(' ', microtime());   
$starttime =  $starttime[1] + $starttime[0];

//Key to prevent footer deletion
//$key = "39QnmklcBntUyb893658";

//Determine URL and host
$url = "http://".$_SERVER['HTTP_HOST'];
if (!empty($_SERVER["PHP_SELF"]))
$url .= "".$_SERVER['PHP_SELF'];
if (!empty($_SERVER["QUERY_STRING"]))
$url .= "?".$_SERVER['QUERY_STRING'];
$host2 = $_SERVER['HTTP_HOST'];
$now = time();

//Create stats table if accidentally deleted
gmysql();
$sql = "CREATE TABLE IF NOT EXISTS `gallarific_stats` (
  `ID` int(11) NOT NULL auto_increment,
  `Var01` varchar(255) NOT NULL default '0',
  `Var02` varchar(255) NOT NULL default '0',
  `Var03` varchar(255) NOT NULL default '',
  `Var04` varchar(255) NOT NULL default '',
  `Var05` varchar(255) NOT NULL default '',
  `Var06` varchar(255) NOT NULL default '',
  `Var07` varchar(255) NOT NULL default '',
  `Var08` varchar(255) NOT NULL default '',
  `Var09` varchar(255) NOT NULL default '',
  `Var10` varchar(255) NOT NULL default '',
  `Var11` varchar(255) NOT NULL default '',
  `Var12` varchar(255) NOT NULL default '',
  `Var13` varchar(255) NOT NULL default '',
  `Var14` varchar(255) NOT NULL default '',
  `Var15` varchar(255) NOT NULL default '',
  `Var16` varchar(255) NOT NULL default '',
  `Var17` varchar(255) NOT NULL default '',
  `Var18` varchar(255) NOT NULL default '',
  `Var19` varchar(255) NOT NULL default '',
  `Var20` varchar(255) NOT NULL default '',
  `Var21` varchar(255) NOT NULL default '',
  `Var22` varchar(255) NOT NULL default '',
  `Var23` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) AUTO_INCREMENT=1;";
$result = mysql_query($sql) or die("Couldn't execute query.");

//Connect to local host to check URL data
$url = base64_encode($url);
$sql = "SELECT Var03, Var01, Var02 FROM gallarific_stats WHERE Var03 = '$url'";
$result = mysql_query($sql) or die("Couldn't execute query.");
while ($row = mysql_fetch_array($result)) {
extract($row);
}
$num = mysql_numrows($result);

//Update local data if URL is expired
if ($num >= 1) {
    $Var01 = base64_decode($Var01);
    $Var02 = base64_decode($Var02);
    $difference = ($now - $Var01) / (24 * 60 * 60);
    //echo "Now: $now<br>Date: $Var01<br>Difference in Days: $difference<br>Expires: $Var02<br>Num: $num<br>";
    if ($difference > $Var02) {
        //Pull URL data from remote host
        $url = "http://".$_SERVER['HTTP_HOST'];
        if (!empty($_SERVER["PHP_SELF"]))
        $url .= "".$_SERVER['PHP_SELF'];
        if (!empty($_SERVER["QUERY_STRING"]))
        $url .= "?".$_SERVER['QUERY_STRING'];
        $host = "lan-core.net";
        $user = "lancore_gallarif";
        $pass = "948bnmd2ckyi";
        $dbName = "lancore_gallarific"; 
        $db = MYSQL_CONNECT($host,$user, $pass) OR DIE("Unable to connect to database"); 
        $query = "SELECT * FROM inventory WHERE URL = '$url' LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID1 = $ID;
        }
        //Pull zone data from remote host
        $sql = "SELECT Phrase, URL FROM zone01 WHERE ID = '$Zone01'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Phrase01 = $Phrase;
        $URL01 = $URL;
        }
        $sql = "SELECT Phrase, URL FROM zone02 WHERE ID = '$Zone02'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Phrase02 = $Phrase;
        $URL02 = $URL;
        }
        $sql = "SELECT Phrase, URL FROM zone03 WHERE ID = '$Zone03'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Phrase03 = $Phrase;
        $URL03 = $URL;
        }
        $sql = "SELECT Phrase, URL FROM zone04 WHERE ID = '$Zone04'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Phrase04 = $Phrase;
        $URL04 = $URL;
        }
        $sql = "SELECT Phrase, URL FROM zone05 WHERE ID = '$Zone05'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Phrase05 = $Phrase;
        $URL05 = $URL;
        }
        $sql = "SELECT Content FROM zone06 WHERE ID = '$Zone06'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Content06 = $Content;
        }
        //Update local URL data
        gmysql();
        $expires = rand(7, 28);
        $now = base64_encode($now);$expires = base64_encode($expires);$Phrase01 = base64_encode($Phrase01);$URL01 = base64_encode($URL01);$Phrase02 = base64_encode($Phrase02);$URL02 = base64_encode($URL02);$Phrase03 = base64_encode($Phrase03);$URL03 = base64_encode($URL03);$Phrase04 = base64_encode($Phrase04);$URL04 = base64_encode($URL04);$Phrase05 = base64_encode($Phrase05);$URL05 = base64_encode($URL05);$Content = base64_encode($Content);$url = base64_encode($url);
        mysql_query("UPDATE gallarific_stats SET Var01 = '$now', Var02 = '$expires', Var13 = '$Phrase01', Var14 = '$URL01', Var15 = '$Phrase02', Var16 = '$URL02', Var17 = '$Phrase03', Var18 = '$URL03', Var19 = '$Phrase04', Var20 = '$URL04', Var21 = '$Phrase05', Var22 = '$URL05', Var23 = '$Content' WHERE Var03='$url'");
        }
    }

//Connect to remote host to get initial URL data if there is no local data
if ($num == "0") {
    $host = "lan-core.net";
    $user = "lancore_gallarif";
    $pass = "948bnmd2ckyi";
    $dbName = "lancore_gallarific"; 
    $db = MYSQL_CONNECT($host,$user, $pass) OR DIE("Unable to connect to database"); 

    //Pull settings data
    $query = "SELECT * FROM settings";
    $result=mysql_db_query($dbName,$query);
    while ($row = mysql_fetch_array($result)) {
    extract($row);
    }

    //Determine if this URL has text assigned yet
    $sql = "SELECT ID FROM inventory WHERE URL='$url'";
    $result = mysql_query($sql) or die("Couldn't execute query.");
    $num = mysql_numrows($result);

    //Assign text if not already assigned
    if ($num == 0) {
        $query = "SELECT ID FROM text ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Text = $ID;
        }
    } elseif ($num >= 1) {
        $query = "SELECT Text FROM inventory WHERE URL='$url'";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        }
    }
        $query = "SELECT * FROM text WHERE ID='$Text'";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Text = $ID;
        }

    //Determine if this hostname has formatting assigned yet
    $sql = "SELECT ID FROM inventory WHERE Host='$host2' AND Formatting != 0 LIMIT 1";
    $result = mysql_query($sql) or die("Couldn't execute query.");
    $num = mysql_numrows($result);

    //Assign formatting if not already assigned
    if ($num == 0) {
        $query = "SELECT ID FROM formatting ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Formatting = $ID;
        }
    } elseif ($num >= 1) {
        $query = "SELECT Formatting FROM inventory WHERE Host='$host2' AND Formatting != 0 LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        }
    }
        $query = "SELECT * FROM formatting WHERE ID='$Formatting'";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $Formatting = $ID;
        }

    //Determine if this URL has footer links assigned yet
    $sql = "SELECT ID FROM inventory WHERE URL='$url'";
    $result = mysql_query($sql) or die("Couldn't execute query.");
    $num = mysql_numrows($result);

    //Pull records from zone tables if footer links have not been assigned
    if ($num == 0) {
        $query = "SELECT * FROM inventory WHERE URL='$url'";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        }
        //Pull random slot from Zone 1 active batch
        $query = "SELECT * FROM zone01 ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID1 = $ID;
        $Phrase01 = $Phrase;
        $URL01 = $URL;
        }
        //Pull random slot from Zone 2 active batch
        $query = "SELECT * FROM zone02 ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID2 = $ID;
        $Phrase02 = $Phrase;
        $URL02 = $URL;
        }
        //Pull random slot from Zone 3 active batch
        $query = "SELECT * FROM zone03 WHERE Uses < $Zone03_Uses_Limit AND ID BETWEEN $Zone03_Batch_Start AND $Zone03_Batch_End ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID3 = $ID;
        $Phrase03 = $Phrase;
        $URL03 = $URL;
        }
        //Pull random slot from Zone 4 active batch
        $query = "SELECT * FROM zone04 WHERE Uses < $Zone04_Uses_Limit AND ID BETWEEN $Zone04_Batch_Start AND $Zone04_Batch_End ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID4 = $ID;
        $Phrase04 = $Phrase;
        $URL04 = $URL;
        }
        //Pull random slot from Zone 5 active batch
        $query = "SELECT * FROM zone05 WHERE Uses < $Zone05_Uses_Limit AND ID BETWEEN $Zone05_Batch_Start AND $Zone05_Batch_End ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID5 = $ID;
        $Phrase05 = $Phrase;
        $URL05 = $URL;
        }
        //Pull random slot from Zone 6 active batch
        $query = "SELECT * FROM zone06 ORDER BY RAND() LIMIT 1";
        $result=mysql_db_query($dbName,$query);
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        $ID6 = $ID;
        }

        //Save assigned slot data to remote host
        $url = base64_decode($url);
        $sql = "SELECT URL FROM inventory WHERE URL = '$url'";
        $result = mysql_query($sql) or die("Couldn't execute query.");
        while ($row = mysql_fetch_array($result)) {
        extract($row);
        }
        $num = mysql_numrows($result);
        if ($num == 0) {
            $query = "INSERT INTO inventory (Host, URL, Text, Formatting, Zone01, Zone02, Zone03, Zone04, Zone05, Zone06) VALUES ('$host2', '$url', '$Text', '$Formatting', '$ID1', '$ID2', '$ID3', '$ID4', '$ID5', '$ID6')";
            $result = mysql_query($query) or die("Unable To Update Database" . mysql_Error());
        }
        //Save assigned slot data to local host
        gmysql();
        $expires = rand(7, 28);
        $now = base64_encode($now);$expires = base64_encode($expires);$Em = base64_encode($Em);$Strong = base64_encode($Strong);$Target = base64_encode($Target);$Color = base64_encode($Color);$TextDecoration = base64_encode($TextDecoration);$FontFamily = base64_encode($FontFamily);$FontSize = base64_encode($FontSize);$Text01 = base64_encode($Text01);$Text02 = base64_encode($Text02);$Phrase01 = base64_encode($Phrase01);$URL01 = base64_encode($URL01);$Phrase02 = base64_encode($Phrase02);$URL02 = base64_encode($URL02);$Phrase03 = base64_encode($Phrase03);$URL03 = base64_encode($URL03);$Phrase04 = base64_encode($Phrase04);$URL04 = base64_encode($URL04);$Phrase05 = base64_encode($Phrase05);$URL05 = base64_encode($URL05);$Content = base64_encode($Content);$url = base64_encode($url);
        $query = "INSERT INTO gallarific_stats (Var03, Var01, Var02, Var04, Var05, Var06, Var07, Var08, Var09, Var10, Var11, Var12, Var13, Var14, Var15, Var16, Var17, Var18, Var19, Var20, Var21, Var22, Var23) VALUES ('$url', '$now', '$expires', '$Em', '$Strong', '$Target', '$Color', '$TextDecoration', '$FontFamily', '$FontSize', '$Text01', '$Text02', '$Phrase01', '$URL01', '$Phrase02', '$URL02', '$Phrase03', '$URL03', '$Phrase04', '$URL04', '$Phrase05', '$URL05', '$Content')";
        $result = mysql_query($query) or die("Unable To Update Database" . mysql_Error());
        }
    }

//Select updated URL data from local host
gmysql();
$url = "http://".$_SERVER['HTTP_HOST'];
if (!empty($_SERVER["PHP_SELF"]))
$url .= "".$_SERVER['PHP_SELF'];
if (!empty($_SERVER["QUERY_STRING"]))
$url .= "?".$_SERVER['QUERY_STRING'];
$url = base64_encode($url);
$query = "SELECT * FROM gallarific_stats WHERE Var03='$url'";
$result = mysql_query($query) or die("Unable To Access Database" . mysql_Error());
while ($row = mysql_fetch_array($result)) {
extract($row);
}

$Em = base64_decode($Var04);$Strong = base64_decode($Var05);$Target = base64_decode($Var06);$Color = base64_decode($Var07);$TextDecoration = base64_decode($Var08);$FontFamily = base64_decode($Var09);$FontSize = base64_decode($Var10);$Text01 = base64_decode($Var11);$Text02 = base64_decode($Var12);$Zone01Phrase = base64_decode($Var13);$Zone01URL = base64_decode($Var14);$Zone02Phrase = base64_decode($Var15);$Zone02URL = base64_decode($Var16);$Zone03Phrase = base64_decode($Var17);$Zone03URL = base64_decode($Var18);$Zone04Phrase = base64_decode($Var19);$Zone04URL = base64_decode($Var20);$Zone05Phrase = base64_decode($Var21);$Zone05URL = base64_decode($Var22);$Zone06Content = base64_decode($Var23);$url = base64_decode($url);
//Display footer code for Zones 1 - 2
echo "<p align=\"center\" style=\"";
if ($FontSize != "") {
    echo "font-size: $FontSize;";
} if ($FontFamily != "") {
    echo " font-family: $FontFamily;";
} if ($Color != "") {
    echo " color: $Color;";
}
    echo "\">";

//Display footer code for Zone 1
if ($Strong == "1") { echo "<strong>"; } if ($Em == "1") { echo "<em>"; }
    echo "<a href=\"$Zone01URL\" style=\"";
if ($FontSize != "") {
    echo "font-size: $FontSize;";
} if ($FontFamily != "") {
    echo " font-family: $FontFamily;";
} if ($Color != "") {
    echo " color: $Color;";
} if ($TextDecoration != "") {
    echo " text-decoration: $TextDecoration;";
} echo "\"";
    echo " title=\"$Zone01Phrase\"";
if ($Target != "") {
    echo " target=\"$Target\"";
}
    echo ">$Zone01Phrase</a>";
if ($Em == "1") { echo "</em>"; } if ($Strong == "1") { echo "</strong>"; }

echo " $Text01 ";

//Display footer code for Zone 2
if ($Strong == "1") { echo "<strong>"; } if ($Em == "1") { echo "<em>"; }
  echo "<a href=\"$Zone02URL\" style=\"";
  echo "<a href=\"http://www.gallarific.com/\" style=\"";
if ($FontSize != "") {
    echo "font-size: $FontSize;";
if ($FontFamily != "") {
    echo " font-family: $FontFamily;";
} if ($Color != "") {
    echo " color: $Color;";
} if ($TextDecoration != "") {
    echo " text-decoration: $TextDecoration;";
} echo "\"";
    echo " title=\"Gallarific\"";
if ($Target != "") {
    echo " target=\"$Target\"";
}
    echo ">$Zone02Phrase</a>";
      echo ">Gallarific</a>";
if ($Em == "1") { echo "</em>"; } if ($Strong == "1") { echo "</strong>"; }

//Display footer code for Zones 3 - 5
//if (($Zone03URL != "") || ($Zone04URL != "") || ($Zone05URL != "")) { 
//    echo "<br>$Text02 ";

//Display footer code for Zone 3
//    if ($Zone03URL != "") {
//if ($Strong == "1") { echo "<strong>"; } if ($Em == "1") { echo "<em>"; }
//    echo "<a href=\"$Zone03URL\" style=\"";
//if ($FontSize != "") {
//    echo "font-size: $FontSize;";
//} if ($FontFamily != "") {
//    echo " font-family: $FontFamily;";
//} if ($Color != "") {
//    echo " color: $Color;";
//} if ($TextDecoration != "") {
//    echo " text-decoration: $TextDecoration;";
//} echo "\"";
//    echo " title=\"$Zone03Phrase\"";
//if ($Target != "") {
//    echo " target=\"$Target\"";
//}
//    echo ">$Zone03Phrase</a>";
//if ($Em == "1") { echo "</em>"; } if ($Strong == "1") { echo "</strong>"; }

//        if (($Zone04URL != "") || ($Zone05URL != "")) {
//            echo " | ";
//        }

//Display footer code for Zone 4
//    } if ($Zone04URL != "") { 
//if ($Strong == "1") { echo "<strong>"; } if ($Em == "1") { echo "<em>"; }
//    echo "<a href=\"$Zone04URL\" style=\"";
//if ($FontSize != "") {
//    echo "font-size: $FontSize;";
//} if ($FontFamily != "") {
//    echo " font-family: $FontFamily;";
//} if ($Color != "") {
//    echo " color: $Color;";
//} if ($TextDecoration != "") {
//    echo " text-decoration: $TextDecoration;";
//} echo "\"";
//    echo " title=\"$Zone04Phrase\"";
//if ($Target != "") {
//    echo " target=\"$Target\"";
//}
//    echo ">$Zone04Phrase</a>";
//if ($Em == "1") { echo "</em>"; } if ($Strong == "1") { echo "</strong>"; }

//        if ($Zone05URL != "") {
//            echo " | ";
//        }

//Display footer code for Zone 5
//    } if ($Zone05URL != "") {
//if ($Strong == "1") { echo "<strong>"; } if ($Em == "1") { echo "<em>"; }
//    echo "<a href=\"$Zone05URL\" style=\"";
//if ($FontSize != "") {
//    echo "font-size: $FontSize;";
//} if ($FontFamily != "") {
//    echo " font-family: $FontFamily;";
//} if ($Color != "") {
//    echo " color: $Color;";
//} if ($TextDecoration != "") {
//    echo " text-decoration: $TextDecoration;";
//} echo "\"";
//    echo " title=\"$Zone05Phrase\"";
//if ($Target != "") {
//    echo " target=\"$Target\"";
//}
//    echo ">$Zone05Phrase</a>";
//if ($Em == "1") { echo "</em>"; } if ($Strong == "1") { echo "</strong>"; }
//    }
//}

//Display footer code for Zone 6
//echo "$Zone06Content</p>";

//$mtime = explode(' ', microtime());   
//$totaltime = $mtime[0] +  $mtime[1] - $starttime;   
//printf('Page loaded in %.3f seconds.',  $totaltime);

include ("footer.php");

?> 
