<?php

	$popular_photos = gpopular($GLOBALS["gallarific_popular_photos"]);
	$i = 0;
	$j = 0;

	echo "<!-- popular_grid: output a 4x1 row containing the most viewed photos -->";
	echo "<tr>";
	echo " <td colspan=\"2\" class=\"heading\">Most Viewed Photos</td>";
	echo "</tr>";
	echo "<tr>";

	if(sizeof($popular_photos) > 0) {
		echo " <td colspan=\"2\">";
		echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
		echo " <tr>";

		foreach($popular_photos as $photo) {
			$i++;
			$j++;

			if($photo["views"] == 1)
				$views = sprintf("%s view", number_format($photo["views"]));
			else
				$views = sprintf("%s views", number_format($photo["views"]));

			$desc = "";

			if($photo["description"] != "") {
				if(strlen($photo["description"]) < 50)
					$desc = $photo["description"];
				else
					$desc = substr($photo["description"], 0, 50) . "...";

				$desc .= "<br />";
			}
			$title = "";
			if($photo["title"] != "") {
				if(strlen($photo["title"]) < 50)
					$title = $photo["title"];
				else
					$title = substr($photo["title"], 0, 50) . "...";

				$title .= "<br />";
			}else{
				$title .= "<br />";
			}

			printf("<td width=\"25%%\" class=\"grid border\" valign=\"top\"><a href=\"%s\">%s<img src=\"photos/thumb_%s\" border=\"0\" /><br />%s</a>(%s)</td>", glink($photo["photoid"], LINK_PHOTO), $title, $photo["filename"], $desc, $views);

			if($i == 4) {
				echo "</tr><tr>";
				$i = 0;
			}
		}

		echo " </tr>";
		echo "</table>";

	}
	else {
		echo " <td class=\"pad\" colspan=\"2\">No photos have been uploaded.";
	}

	echo " </td>";
	echo "</tr>";
	echo "<!-- popular_grid_end -->";

?>


