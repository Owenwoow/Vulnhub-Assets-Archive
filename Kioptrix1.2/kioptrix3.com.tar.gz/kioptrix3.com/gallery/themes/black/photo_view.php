<?php

	// Unset variables that may have not been cleared if the
	// user exited a slideshow early
	unset($_SESSION["gallarific_slideshow_first"]);
	unset($_SESSION["gallarific_slideshow_tag"]);
	$photo_id = escape($_GET["id"]);
	$sort = escape($_GET["sort"]);
	$tag = escape($_GET["tag"]);
	$photo = gphoto();
	$nextprev = gnextprev();
	$comments = gcomments();
	$cclass = 1;
	$subnav = "";
	$psort = "";
	$user = array();

	// If we're logged in, get the users name, email and web site so
	// they don't have to fill them out in the comment form
	if(gisloggedin())
		$user = guserdetails();

	$photo_path = realpath(dirname(__FILE__) . "/../../");

	if(sizeof($photo) > 0) {
		
		list($iwidth, $height, $type, $attr) = getimagesize($photo_path . "/photos/" . $photo["filename"]);

		if($iwidth > MAX_IMAGE_WIDTH)
			$width = MAX_IMAGE_WIDTH;
		else
			$width = $iwidth;

	if($sort != "")
		$psort = sprintf("&sort=%s", $sort);

	if($tag == "") {
		if(isset($nextprev["prev"]))
			$subnav .= sprintf("<a href=\"p.php/%d%s\">&laquo; Previous Photo</a> | ", $nextprev["prev"], $psort);

		if(isset($nextprev["next"]))
			$subnav .= sprintf("<a href=\"p.php/%d%s\">Next Photo &raquo;</a>", $nextprev["next"], $psort);
	}
	else {

		if(isset($nextprev["prev"]))
			$subnav .= sprintf("<a href=\"photos.php?id=%d%s&tag=%s\">&laquo; Previous Photo</a> | ", $nextprev["prev"], $psort, urlencode($tag));

		if(isset($nextprev["next"]))
			$subnav .= sprintf("<a href=\"photos.php?id=%d%s&tag=%s\">Next Photo &raquo;</a>", $nextprev["next"], $psort, urlencode($tag));
	}

	$subnav = eregi_replace("\| $", "", $subnav);

	// Workout the average vote
	$vote = -1;

	if($photo["votecount"] > 0)
		$vote = floor((int)($photo["votetotal"] / $photo["votecount"]));

	$url = urlencode(sprintf("%s?%s", $_SERVER["REQUEST_URI"], $_SERVER["QUERY_STRING"]));

	?>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="heading padlr" align="right"><?php echo $subnav; ?></td>
			</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="470">
					<div class="image">
						<div><?php echo $photo["title"]; ?></div>
						<?php if($iwidth > MAX_IMAGE_WIDTH) { ?>
							<a href="photos/<?php echo $photo["filename"]; ?>" target="_blank"><img src="photos/<?php echo $photo["filename"]; ?>" width="<?php echo $width; ?>" border="0" /></a>
							<br /><center>[Click on the photo for a larger view]</center>
						<?php } else { ?>
							<img src="photos/med_<?php echo $photo["filename"]; ?>" />
						<?php } ?>
						
					</div>
					<div style="padding-left : 20px;"><strong><?php echo $photo["description"]; ?></strong></div>
					<br><br>
				</td>
				<td valign="top">
					<br /><br />
					<?php if($photo["description"] != "") { echo "<br />"; } ?>
					<table width="260" align="left" border="0" class="details">
						<tr>
							<td class="padlr padt" colspan="2">
								<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" /><h2>Photo Details</h2>
							</td>
						</tr>
						<tr>
							<td width="100" class="description">File Name:</td>
							<td class="data"><a href="photos/<?php echo $photo["filename"]; ?>" target="_blank"><?php echo $photo["filename"]; ?></a></td>
						</tr>
						<tr>
							<td width="100" class="description">Uploaded:</td>
							<td class="data"><?php echo date($GLOBALS["gallarific_date_format"], $photo["dateuploaded"]); ?></td>
						</tr>
						<tr>
							<td width="100" class="description">File Size:</td>
							<td class="data"><?php echo number_format(ceil($photo["size"]/1024)); ?> KB</td>
						</tr>
						<tr>
							<td width="100" class="description">Views:</td>
							<td class="data"><?php echo number_format($photo["views"]); ?></td>
						</tr>
						<tr>
							<td width="100" class="description">Tags:</td>
							<td class="data"><?php echo gparsetags($photo["tags"]); ?></td>
						</tr>
						<tr>
							<td width="100" class="description" valign="top">Rating:</td>
							<td class="data">
									<?php for($i = 0; $i < $vote; $i ++) { ?>
										<a title="Click here to rate this image <?php echo $i+1; ?> out of 5" href="vote.php?id=<?php echo $photo["photoid"]; ?>&vote=<?php echo $i+1; ?>&from=<?php echo $url; ?>"><img src="<?php echo THEME_PATH; ?>images/star1.gif" width="11" height="12" border="0" /></a>
									<?php } ?>
									<?php if($vote == -1) { $vote = 0; } ?>
									<?php for($i = $vote; $i < 5; $i++) { ?>
										<a title="Click here to rate this image <?php echo $i+1; ?> out of 5" href="vote.php?id=<?php echo $photo["photoid"]; ?>&vote=<?php echo $i+1; ?>&from=<?php echo $url; ?>"><img src="<?php echo THEME_PATH; ?>images/star2.gif" width="11" height="12" border="0" /></a>
									<?php } ?>
								<?php if($vote < 1) { ?>
									<br />[Not Rated Yet]
								<?php } else { ?>
									<br />[From <?php echo $photo["votecount"]; ?> rating<?php if($photo["votecount"] != 1) { echo "s"; } ?>]
								<?php } ?>
								<br><div class="help_text">Click a star to vote</div></td>
						</tr>
						<tr>
							<td colspan="2">&nbsp;</td>
						</tr>
					</table>
					<br /><br />
				</td>
			</tr>
		</table>
	<?php
	}

?>