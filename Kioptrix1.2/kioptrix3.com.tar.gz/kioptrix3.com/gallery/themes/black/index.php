  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('menu'); ?>
   <?php ginclude('links'); ?>
   <?php ginclude('recent_grid'); ?>
   <tr>
    <td colspan="2">
     <table cellspacing="0" cellpadding="0" class="heading">
      <tr>
       <td width="50" nowrap>&nbsp;</td>
       <td width="40%" class="title">Gallery</td>
       <td width="30%" class="title">Last Upload</td>
       <td width="15%" class="title"><center>Photos</center></td>
       <td width="15%" class="title"><center>Views</center></td>
      </tr>
     </table>
	 <?php ginclude('gallery_grid'); ?>
	</td>
   </tr>
   <?php ginclude('popular_grid'); ?>
   <?php ginclude('gallery_stats'); ?>
  </table>
  <?php if(isset($_GET["session_expired"])) { ?>
   <script>alert("Your session has timed out. Please login again.");</script>
  <?php } ?>
