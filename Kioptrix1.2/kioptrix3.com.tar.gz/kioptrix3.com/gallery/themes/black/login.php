<?php

	$error = "";
	$user_name = "";
	$is_loggedin = glogin($error, $user_name);

	?>
  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="heading padlr">
					Account Login
				</td>
			</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%" class="pad">
					<div class="help">
						<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" />
						<?php if($is_loggedin) { ?>
							Thank you for logging in <?php echo $user_name; ?>. You are being taken back to the gallery...
							<script>window.setTimeout("document.location.href='index.php'", 3000);</script>
						<?php } else { ?>
							<?php echo $error; ?>
						<?php } ?>
					</div>
				</td>
			</tr>
		</table>
	</td>
   </tr>
  </table>
