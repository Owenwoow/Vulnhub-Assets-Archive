  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
     <?php ginclude('recent_view'); ?>
	</td>
   </tr>
  </table>
