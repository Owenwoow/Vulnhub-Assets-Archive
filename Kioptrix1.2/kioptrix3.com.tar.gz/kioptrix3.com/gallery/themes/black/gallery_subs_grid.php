<?php

	$parent_id = $_GET['id'];
	$selcat="SELECT * from gallarific_galleries where parentid=$parent_id order by parentid,sort,name";
	$selcat2=mysql_query($selcat) or die(mysql_error()."Could not select category");
	if(mysql_num_rows($selcat2)!=0){
	$sqls = mysql_query("select * from gallarific_galleries order by parentid,sort,name");
	$num_childs = traverse_count($parent_id,0, $sqls);
	$arr = explode(",",$num_childs);
	
	?>
     <table cellspacing="0" cellpadding="0" class="heading">
      <tr>
       <td width="50" nowrap>&nbsp;</td>
       <td width="40%" class="title"><? if(sizeof($arr)>2){ echo "Sub Galleries"; }else{echo "Sub Gallery"; }?></td>
       <td width="30%" class="title">Last Upload</td>
       <td width="15%" class="title"><center>Photos</center></td>
       <td width="15%" class="title"><center>Views</center></td>
      </tr>
     </table>
	<?php

		echo "<table cellspacing=\"0\" cellpadding=\"0\">";
		$bb = "borderbottom";
		while ($acat = mysql_fetch_array($selcat2)){
			echo " <tr>";
			printf("<td width=\"50\" class=\"grid_border %s\" nowrap valign=\"top\"><center><img class=\"pad\" src=\"", $bb);
			ginfo("image_path");
			echo "/gr_icon.gif\" width=\"38\" height=\"39\" /></center></td>";
			printf("<td valign=\"top\" width=\"40%%\" class=\"pad grid_border %s\">", $bb);
		
			printf("	<a href=\"%s\" class=\"gallery\">%s</a>", glink($acat["galleryid"], LINK_GALLERY), $acat["name"]);
			if($acat["description"] != "")
				printf("<div class=\"desc\">%s</div>", $acat["description"]);
			else
				echo "<br />";
			$qry = "select * from gallarific_galleries where parentid = '{$acat["galleryid"]}'";
			$result = mysql_query($qry);
			$sql_rst = mysql_query("select * from gallarific_galleries order by parentid,sort,name");
			if(mysql_num_rows($result)!=0){
				echo "<strong>Sub Galleries:</strong>";
				echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
				echo " <tr>";
				echo "  <td class=\"subs\">";
				traverse($acat["galleryid"],0,$sql_rst);
				echo "  </td>";
				echo " </tr>";
				echo "</table>";
			}
			echo "</td>";
			$lastUpload = lastuploaded($acat["galleryid"]);
			printf("   <td width=\"30%%\" class=\"pad grid_border lastpost %s\" valign=\"top\" align=\"center\">%s</td>", $bb, $lastUpload);
			$photo_count = photocount($acat["galleryid"]);
			echo "   <td width=\"15%%\" class=\"pad grid_border count $bb\" valign=\"top\"><center>".number_format($photo_count)."</center></td>";
			$view_count = viewcount($acat["galleryid"]);
			echo "   <td width=\"15%%\" class=\"pad $bb\" valign=\"top\"><center>".number_format($view_count)."</center></td>";
			echo "</tr>";
		}
		echo "</table>";
	}

function traverse($root, $depth, $sql){
	$row=0;
	while ($acat = mysql_fetch_array($sql)){
		if ($acat['parentid'] == $root){
			
			$j=0;
			
			print "<table><tr><td valign='top'>";
			while ($j<$depth){
				print "&nbsp;&nbsp;";
				$j++;
			}
			if($depth>0){
				print "&nbsp;";
			}
			print "</td><td>";
			printf("<li><a href=\"%s\">%s</a>", glink($acat["galleryid"], LINK_GALLERY), $acat["name"]);
			if($acat["description"] != "")
				echo sprintf("<div>%s</div>", $acat["description"]);
			echo "</li></td></tr></table>";			
			mysql_data_seek($sql,0); 
			traverse($acat['galleryid'], $depth+1,$sql);
		}
		$row++;
		mysql_data_seek($sql,$row);
	}
} 
function lastuploaded($galleryid){
	global $gall_ids;
	$gall_ids ='';
	$sql = mysql_query("select * from gallarific_galleries");
	$galls = traverse_count($galleryid,0, $sql);
	$galls .=$galleryid;
	$query = sprintf("select photoid, filename, title, description, dateuploaded from gallarific_photos where status='1' and galleryid in (%s) order by dateuploaded desc limit 1", $galls);
	
	$result = mysql_query($query) or die(mysql_error());

	if($photo = mysql_fetch_array($result)) {
		if($photo["description"] != "") {
				if(strlen($photo["description"]) < 50)
					$desc = $photo["description"];
				else
					$desc = substr($photo["description"], 0, 50) . "...";

				$desc .= "<br />";
			}
			$title = "";
			if($photo["title"] != "") {
				if(strlen($photo["title"]) < 50)
					$title = $photo["title"];
				else
					$title = substr($photo["title"], 0, 50) . "...";

				$title .= "<br />";
			}else{
				$title .= "<br />";
			}
			$lastUpload = sprintf("<center><a href=\"%s\">%s<img src=\"photos/thumb_%s\" border=\"0\" /><br>%s</a></center>",glink($photo["photoid"], LINK_PHOTO), $title, $photo["filename"],$desc);
	}
	else {
		$lastUpload = "N/A";
	}
	return $lastUpload;
}

function photocount($galleryid){
	global $gall_ids;
	$gall_ids ='';
	$sql = mysql_query("select * from gallarific_galleries");
	$galls = traverse_count($galleryid,0, $sql);
	$galls .=$galleryid;
	$query = "select count(photoid) from gallarific_photos where status='1' and galleryid in ($galls)";
		$result = mysql_query($query) or die(mysql_error());
		$row = mysql_fetch_row($result);
		$photo_count = $row[0];
		return $photo_count;
}

function viewcount($galleryid){
	global $gall_ids;
	$gall_ids ='';
	$sql = mysql_query("select * from gallarific_galleries");
	$galls = traverse_count($galleryid,0, $sql);
	$galls .=$galleryid;
	$query = "select sum(views) from gallarific_photos where status='1' and galleryid in ($galls)";
			$result = mysql_query($query);
			$row = mysql_fetch_row($result);
			$view_count = $row[0];
	return $view_count;
}

function traverse_count($root, $depth, $sql){
	global $gall_ids;
	$row=0;
	while ($acat = mysql_fetch_array($sql)){
		if ($acat['parentid'] == $root){
			$gall_ids .= $acat['galleryid'].",";
			mysql_data_seek($sql,0); 
			traverse_count($acat['galleryid'], $depth+1,$sql);
		}
		$row++;
		mysql_data_seek($sql,$row);
	}
	return $gall_ids;

}

?>