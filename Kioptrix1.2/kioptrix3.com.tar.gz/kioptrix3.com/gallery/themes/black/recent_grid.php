<?php

	$recent_photos = grecent($GLOBALS["gallarific_recent_photos"]);
	$i = 0;
	$j = 0;

	echo "<!-- recent_grid: output a 4x1 row containing recently uploaded photos -->";
	echo "<tr>";
	echo " <td colspan=\"2\" class=\"heading\">Recently Uploaded Photos</td>";
	echo "</tr>";
	echo "<tr>";

	if(sizeof($recent_photos) > 0) {
		echo " <td colspan=\"2\">";
		echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">";
		echo " <tr>";

		foreach($recent_photos as $photo) {
			$i++;
			$j++;
			$desc = "";

			if($photo["description"] != "") {
				if(strlen($photo["description"]) < 50)
					$desc = $photo["description"];
				else
					$desc = substr($photo["description"], 0, 50) . "...";

				$desc .= "<br />";
			}
			$title = "";
			if($photo["title"] != "") {
				if(strlen($photo["title"]) < 50)
					$title = $photo["title"];
				else
					$title = substr($photo["title"], 0, 50) . "...";

				$title .= "<br />";
			}else{
				$title .= "<br />";
			}
			printf("<td valign=\"top\" width=\"25%%\" class=\"grid border\"><a href=\"%s\">%s<img src=\"photos/thumb_%s\" border=\"0\" /><br>%s</a></td>",glink($photo["photoid"], LINK_PHOTO), $title, $photo["filename"],$desc);


			if($i == 4) {
				echo "</tr><tr>";
				$i = 0;
			}
		}

		echo " </tr>";
		echo "</table>";

	}
	else {
		echo " <td class=\"pad\" colspan=\"2\">";
		echo "No photos have been uploaded.";
	}

	echo " </td>";
	echo "</tr>";
	echo "<!-- recent_grid_end -->";

?>


