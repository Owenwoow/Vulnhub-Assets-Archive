<?php

	$query1 = "select count(photoid) from gallarific_photos where status='1'";
	$query2 = "select count(userid) from gallarific_users";
	$query3 = "select count(commentid) from gallarific_comments";

	$gphotos = number_format(mysql_result(mysql_query($query1), 0, 0));
	$gusers = number_format(mysql_result(mysql_query($query2), 0, 0));
	$gcomments = number_format(mysql_result(mysql_query($query3), 0, 0));

?>
  <!-- gallery_stats: outputs statistics for the photo gallery -->
   <tr>
    <td colspan="2" class="heading">Photo Gallery Statistics</td>
   </tr>
   <tr>
    <td colspan="2">
     <table width="100%" cellspacing="0" cellpadding="0">
      <tr>
       <td width="50" nowrap valign="top" align="center"><img class="pad" src="<?php ginfo('image_path'); ?>/gr_stat.gif" width="38" height="39" /></td>
       <td width="100%" class="pad">
        <table>
         <tr>
          <td nowrap class="padlr">Total number of photos uploaded:</td>
          <td><?php echo $gphotos; ?></td>
         </tr>
         <tr>
          <td nowrap class="padlr">Total number of registered users:</td>
          <td><?php echo $gusers; ?></td>
         </tr>
         <tr>
          <td nowrap class="padlr">Total number of comments:</td>
          <td><?php echo $gcomments; ?></td>
         </tr>
        </table>
       </td>
      </tr>
     </table>
    </td>
   </tr>
  <!-- gallery_stats_end -->
