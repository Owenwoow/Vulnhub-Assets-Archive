  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
      <?php
		if(isset($_POST["doupdate"]))
			ginclude('profile_save');
		else
			ginclude('profile_form');
		?>
	</td>
   </tr>
  </table>
