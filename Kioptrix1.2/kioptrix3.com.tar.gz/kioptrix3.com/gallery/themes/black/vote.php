<?php

	ob_end_clean();
	@session_start();

	if(isset($_GET["id"]) && isset($_GET["vote"])) {
		$id = (int)$_GET["id"];
		$vote = (int)$_GET["vote"];
		$from = urldecode($_GET["from"]);

		if(isset($_COOKIE["gallarific_vote_" . $id])) {
		?>
			<script>
				alert("You've already rated this image.");
				history.go(-1);
			</script>
		<?php
		}
		else {
			$query = sprintf("update gallarific_photos set votetotal=votetotal+'%d', votecount=votecount+1 where photoid='%d'", $vote, $id);
			
			if(@mysql_query($query)) {
				setcookie("gallarific_vote_" . $id, 1, time() + (3600*24*365));
			?>
				<script>
					alert("Your rating of <?php echo $vote; ?> out of 5 has been saved.");
					document.location.href = "<?php echo $from; ?>";
				</script>
			<?php
			}
			else {
			?>
				<script>
					alert("Something went wrong when trying to save your rating.");
					history.go(-1);
				</script>
			<?php
			}
		}
	}
	else {
		echo "<script>history.go(-1);</script>";
	}

	die();

?>