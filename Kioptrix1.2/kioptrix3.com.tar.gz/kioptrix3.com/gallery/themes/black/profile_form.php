<?php

	if(gisloggedin()) {
		$user = guserdetails();
		?>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="heading padlr">
					Update Your Profile
				</td>
			</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%" class="pad">
					<div class="help">
						<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" />
						Complete the form below to update your member profile. All fields can be changed except your username.
					</div>
					<br />
					<form enctype="multipart/form-data" action="profile.php" method="post" onsubmit="return gallarific_check_profile()">
					<input type="hidden" name="doupdate" value="true">
					<table width="90%" border="0">
						<tr>
							<td width="150" align="right" class="padlr"><strong>Username:</strong></td>
							<td><input type="text" name="username" id="username" size="30" value="<?php echo $user["username"]; ?>" READONLY /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr"><strong>Password:</strong></td>
							<td><input type="password" name="password" id="password" size="30" value="<?php echo $user["password"]; ?>" /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr"><strong>Confirm Password:</strong></td>
							<td><input type="password" name="passwordc" id="passwordc" size="30" value="<?php echo $user["password"]; ?>" /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr"><strong>Email Address:</strong></td>
							<td><input type="text" name="email" id="email" size="30" value="<?php echo $user["email"]; ?>" /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr"><strong>First Name:</strong></td>
							<td><input type="text" name="firstname" id="firstname" size="30" value="<?php echo $user["firstname"]; ?>" /></td>
						</tr>
						<tr>
							<td colspan="2">&nbsp;</td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr">Last Name: (optional)</td>
							<td><input type="text" name="lastname" id="lastname" size="30" value="<?php echo $user["lastname"]; ?>" /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr">Web Site: (optional)</td>
							<td><input type="text" name="website" id="website" size="30" value="<?php echo $user["website"]; ?>" /></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr">Current Photo:</td>
							<td>
							<?php if($user["photo"] != "") { ?>
								<img src="photos/user_<?php echo $user["photo"]; ?>" class="author_photo_1" />
							<?php } else { ?>
								N/A
							<?php } ?>
							</td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr" valign="top">Your Photo: (optional)</td>
							<td><input type="file" name="photo" id="photo" size="30" /><div class="help_text">Leave this field blank to use the current photo.<br />Uploaded photos can be a maximum size of <?php echo ini_get("upload_max_filesize"); ?>B.<br />The photo will be resized to a thumbnail size of <?php echo $GLOBALS["gallarific_userimage_width"]; ?>x<?php echo $GLOBALS["gallarific_userimage_height"]; ?>.</div></td>
						</tr>
						<tr>
							<td width="150" align="right" class="padlr">&nbsp;</td>
							<td><input type="submit" value="Update Profile &raquo;" class="button" /></td>
						</tr>
					</table>
					</form>
					<br /><br />
				</td>
			</tr>
		</table>
	<?php } else { ?>
		<script>document.location.href="index.php?session_expired=true";</script>
<?php	} ?>
