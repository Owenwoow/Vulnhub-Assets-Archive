<?php

	$error = "";
	$user_id = 0;
	$is_registered = gregisteruser($error, $user_id);

	if(!$is_registered) {
		$GLOBALS["register_error"] = $error;
		ginclude('register_form');
	}
	else {
	?>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="heading padlr">
					Register at <?php echo $GLOBALS["gallarific_gallery_name"]; ?>
				</td>
			</tr>
		</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td width="100%" class="pad">
					<div class="help">
						<img src="<?php echo THEME_PATH; ?>images/details.gif" width="25" height="25" align="left" style="margin-right:10px" />
						<?php if(gsendregisterverifyemail($user_id)) { ?>
							Thank you for registering, <?php echo $_POST["username"]; ?>. An email has been dispatched to <?php echo $_POST["email"]; ?> with details on how to activate your account. <a href="index.php">Click here</a> to return to the gallery.
						<?php } else { ?>
							Something went wrong when trying to send your verification email. Please <a href="mailto:<?php echo $GLOBALS["gallarific_email"]; ?>">email the administrator</a> of the photo gallery and ask him/her to make sure emails can be sent from the server.
						<?php } ?>
					</div>
				</td>
			</tr>
		</table>
	<?php
	}

?>