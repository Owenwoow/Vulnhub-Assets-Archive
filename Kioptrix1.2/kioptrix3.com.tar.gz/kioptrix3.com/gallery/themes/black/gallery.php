  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
     <?php ginclude('gallery_subs_grid'); ?>
	</td>
   </tr>
   <tr>
    <td colspan="2">
     <?php ginclude('gallery_photo_grid'); ?>
	</td>
   </tr>
  </table>
