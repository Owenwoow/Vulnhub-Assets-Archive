<?php

	$GLOBALS["gnavmenu"] = gnav();
	echo "<tr>";
	echo " <td class=\"heading\">";

	if(sizeof($GLOBALS["gnavmenu"]) > 0 || isset($_GET["tag"])) {
		echo "  <a href=\"index.php\">Home</a> ";
	}
	else {
		printf("<a class='nounder' href='index.php'>%s</a>", $GLOBALS["gallarific_gallery_name"]);
	}

// for displaying the galleries and subgalleries name 
	if(sizeof($GLOBALS["gnavmenu"]) > 0){
		$size = sizeof($GLOBALS["gnavmenu"]);
		foreach ($GLOBALS["gnavmenu"] as $galleryid=>$name){
			
			printf("&raquo; <a href=\"g.php/%d\">%s</a>",$galleryid, $name);
				
		}

	}

	echo " </td>";
    echo " <td class=\"heading\" align=\"right\" width='50%' valign='top'>";

		
	echo " </td>";
	echo "</tr>";

?>


