<?php

	define("MAX_IMAGE_WIDTH", 430);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Generator" content="Gallarific" />
<title><?php echo gtitle(); ?></title>
<meta name="description" content="<? echo gdescription(); ?>" />
<meta name="keywords" content="<? echo gkeywords(); ?>" />
<base href="<?php echo ginfo('gallarific_path'); ?>"></base>
<link rel="stylesheet" href="<?php ginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo THEME_PATH; ?>javascript.js"></script>
</head>
<body>
 <center>
  <table id="container" cellspacing="0" cellpadding="0">
   <tr>
    <td id="logo">
     <a href="index.php"><img src="<?php ginfo('image_path'); ?>/logo.gif" width="215" height="61" border="0" /></a>
    </td>
   </tr>
  </table>