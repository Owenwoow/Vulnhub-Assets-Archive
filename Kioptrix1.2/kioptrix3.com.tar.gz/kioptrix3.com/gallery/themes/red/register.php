  <table id="main" cellspacing="0" cellpadding="0">
   <?php ginclude('nav'); ?>
   <?php ginclude('links'); ?>
   <tr>
    <td colspan="2">
      <?php
		if(isset($_GET["a"])) {
			ginclude('register_confirm');
		}
		else {
			if(isset($_POST["doregister"]))
				ginclude('register_save');
			else
				ginclude('register_form');
		}
		?>
	</td>
   </tr>
  </table>
