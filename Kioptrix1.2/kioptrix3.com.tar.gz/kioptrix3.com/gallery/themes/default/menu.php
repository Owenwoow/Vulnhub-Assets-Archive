<!-- menu: output the generic gallery navigation menu -->
   <tr>
    <td colspan="2" class="heading">
	 <table width="100%" border="0" cellspacing="0" cellpadding="0">
	  <form action="login.php" method="post" onsubmit="return loginFormCheck()">
	  <tr>
	   <td><?php ginfo('name'); ?></td>
	   <td class="menu" align="right">
       
	   </td>
	  </tr>
	  </form>
	 </table>
	</td>
   </tr>
<!-- menu_end -->
