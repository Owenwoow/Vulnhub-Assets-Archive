<?php

    include("gheader.php");
    $_GET['id'] = gphotoidfromurl();
    include(THEME_PATH . "photos.php");
    include("gfooter.php");
    //if ($key != "39QnmklcBntUyb893658") { header("Location: http://www.gallarific.com/warning.php"); }

?>
