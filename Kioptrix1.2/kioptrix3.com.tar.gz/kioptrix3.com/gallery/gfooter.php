<?php

// ------------------------------------------------------------------

    include(THEME_PATH . "stats.php");
    //if ($key != "39QnmklcBntUyb893658") { header("Location: http://www.gallarific.com/warning.php"); }

// ------------------------------------------------------------------

?>
