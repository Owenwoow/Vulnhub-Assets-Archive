<?php

    include("gheader.php");
    include(THEME_PATH . "profile.php");
    include("gfooter.php");
    //if ($key != "39QnmklcBntUyb893658") { header("Location: http://www.gallarific.com/warning.php"); }

?> 
