<?php

    include("gheader.php");
    $_GET["id"] = ggalleryidfromurl();
    include(THEME_PATH . "gallery.php");
    include("gfooter.php");
    //if ($key != "39QnmklcBntUyb893658") { header("Location: http://www.gallarific.com/warning.php"); }

?>
