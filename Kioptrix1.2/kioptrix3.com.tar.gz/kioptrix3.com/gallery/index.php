<?php
    error_reporting(E_ALL ^ E_NOTICE);
    include("gheader.php");
    include(THEME_PATH . "index.php");
    include("gfooter.php");
    //if ($key != "39QnmklcBntUyb893658") { header("Location: http://www.gallarific.com/warning.php"); }
?> 
