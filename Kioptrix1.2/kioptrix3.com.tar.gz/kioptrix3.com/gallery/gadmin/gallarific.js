function ge(id) {
	return document.getElementById(id);
}

function galleryFormCheck() {
	var nm = ge("name");

	if(nm.value == "") {
		errorBox("You forgot to enter a name for the gallery.");
		nm.focus();
		return false;
	}

	return true;
}

function errorBox(err) {
	var eb = ge("error");
	eb.innerHTML = err;
	eb.style.display = "block";
}

function deleteGallery(id, name) {
	if(confirm("You are about to delete the gallery \"" + name.replace('"', '&quot;') + "\".\n\"OK\" to delete, \"Cancel\" to stop."))
		document.location.href = "gallery.php?task=delete&id=" + id;
}

function photoFormCheck(imageCanBeBlank) {
	var fi = ge("file");
	var gi = ge("galleryid");

	if(!imageCanBeBlank || fi.value != "") {
		if(fi.value == "") {
			alert("You forgot to choose an image file.");
			fi.focus();
			return false;
		}
		else {
			// Make sure the extension is .gif, .jpg or .jpeg
			var ix = fi.value.split(".");
			
			if(ix.length > 0) {
				ext = ix[ix.length-1].toLowerCase();
				
				if(ext != "jpeg" && ext != "jpg" && ext != "gif") {
					alert("Only GIF and JPEG images can be uploaded.");
					fi.focus();
					fi.select();
					return false;
				}
			}
		}
	}

	if(gi.selectedIndex == 0) {
		alert("You forgot to choose a gallery.");
		gi.focus();
		return false;
	}

	loading();
	return true;
}

function loginFormCheck() {
	var un = ge("username");
	var pw = ge("password");

	if(un.value == "") {
		alert("You forgot to enter your username.");
		un.focus();
		return false;
	}

	if(pw.value == "") {
		alert("You forgot to enter your password.");
		pw.focus();
		return false;
	}

	return true;
}

function deletePhoto(id) {
	if(confirm("You are about to delete the selected photo.\n\"OK\" to delete, \"Cancel\" to stop."))
		document.location.href = "photos.php?task=delete&id=" + id;
}

function switchGallery(id) {
	document.location.href = "photos.php?gallery="+id;
}

function deleteComment(id) {
	if(confirm("You are about to delete the selected comment..\n\"OK\" to delete, \"Cancel\" to stop."))
		document.location.href = "comments.php?task=delete&id=" + id;
}

function switchStatus(status) {
	document.location.href = "comments.php?status="+status;
}

function commentFormCheck() {
	var na = ge("name");
	var em = ge("email");
	var le = ge("link");
	var co = ge("comment");

	if(na.value == "") {
		alert("You forgot to enter a name.");
		na.focus();
		return false;
	}

	if(em.value.indexOf(".") == -1 || em.value.indexOf("@") == -1) {
		alert("You forgot to enter a valid email address.");
		em.focus();
		em.select();
		return false;
	}

	if(le.value != "" && le.value.indexOf("http://") != 0) {
		alert("A link must start with 'http://'.");
		le.focus();
		le.select();
		return false;
	}

	if(co.value == "") {
		alert("You forgot to enter a comment.");
		co.focus();
		return false;
	}

	return true;
}

function bulkFormCheck() {
	var fi = ge("file");
	var gi = ge("galleryid");
	var ext = "";
	var ix = fi.value.split(".");

	if(fi.value == "") {
		alert("You forgot to choose a zip file.");
		fi.focus();
		return false;
	}

	if(ix.length > 0)
		ext = ix[ix.length-1].toLowerCase();

	if(ext != "zip") {
		alert("Only ZIP files can be uploaded.");
		fi.focus();
		fi.select();
		return false;
	}

	if(gi.selectedIndex == -1) {
		alert("You forgot to choose a gallery.");
		gi.focus();
		return false;
	}

	loading();
	return true;
}

function loading() {
	var lo = ge("loading");
	lo.style.display = "block";
	lo.style.left = (screen.availWidth/2) - 200 + "px";
	lo.style.top = (screen.availHeight/2) - 150 + "px";
}

function userFormCheck() {
	var ph = ge("photo");
	var un = ge("username");
	var em = ge("email");
	var pw = ge("password");
	var fn = ge("firstname");
	var ro = ge("role");

	if(un.value == "") {
		alert("You forgot to enter a username.");
		un.focus();
		return false;
	}

	if(em.value.indexOf(".") == -1 || em.value.indexOf("@") == -1) {
		alert("You forgot to enter a valid email address.");
		em.focus();
		em.select();
		return false;
	}

	if(pw.value == "") {
		alert("You forgot to enter a password.");
		pw.focus();
		return false;
	}

	if(ro.selectedIndex == 0) {
		alert("You forgot to choose a role.");
		ro.focus();
		return false;
	}

	if(fn.value == "") {
		alert("You forgot to enter a first name.");
		fn.focus();
		return false;
	}

	if(ph.value != "") {
		pht = ph.value.toLowerCase();
		dat = pht.split(".");
		ext = dat[dat.length-1];
		
		if(ext != "gif" && ext != "jpg" && ext != "jpeg") {
			alert("Your photo must be a GIF or JPEG image.");
			ph.focus();
			ph.select();
			return false;
		}
	}

	return true;
}

function deleteUser(id, name) {
	if(confirm("You are about to delete the user account \"" + name.replace('"', '&quot;') + "\".\n\"OK\" to delete, \"Cancel\" to stop."))
		document.location.href = "users.php?task=delete&id=" + id;
}

function sendSearchForm() {
	var qu = ge("query");
	var ga = ge("gallery");
	var gl = ga.options[ga.selectedIndex].value;
	document.location.href = "photos.php?gallery="+gl+"&query="+qu.value;
	return false;
}