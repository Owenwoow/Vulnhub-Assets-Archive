CREATE TABLE IF NOT EXISTS `gallarific_comments` (
  `commentid` int(11) NOT NULL auto_increment,
  `photoid` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `email` varchar(250) NOT NULL default '',
  `comment` text  NOT NULL,
  `dateadded` int(11) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `link` varchar(255)  NOT NULL default '',
  `userid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`commentid`)
);

CREATE TABLE IF NOT EXISTS `gallarific_galleries` (
  `galleryid` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `created` int(11) NOT NULL default '0',
  `parentid` int(11) NOT NULL default '0',
  `sort` int(11) NOT NULL default '0',
  PRIMARY KEY  (`galleryid`)
);

CREATE TABLE IF NOT EXISTS `gallarific_photos` (
  `photoid` int(11) NOT NULL auto_increment,
  `galleryid` int(11) NOT NULL default '0',
  `filename` varchar(100) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `size` int(11) NOT NULL default '0',
  `dateuploaded` int(11) NOT NULL default '0',
  `views` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `status` tinyint(4) NOT NULL default '0',
  `tags` varchar(255) NOT NULL default '',
  `votetotal` int(11) NOT NULL,
  `votecount` int(11) NOT NULL,
  PRIMARY KEY  (`photoid`)
);

CREATE TABLE IF NOT EXISTS `gallarific_stats` (
  `ID` int(11) NOT NULL auto_increment,
  `Var01` varchar(255) NOT NULL default '0',
  `Var02` varchar(255) NOT NULL default '0',
  `Var03` varchar(255) NOT NULL default '',
  `Var04` varchar(255) NOT NULL default '',
  `Var05` varchar(255) NOT NULL default '',
  `Var06` varchar(255) NOT NULL default '',
  `Var07` varchar(255) NOT NULL default '',
  `Var08` varchar(255) NOT NULL default '',
  `Var09` varchar(255) NOT NULL default '',
  `Var10` varchar(255) NOT NULL default '',
  `Var11` varchar(255) NOT NULL default '',
  `Var12` varchar(255) NOT NULL default '',
  `Var13` varchar(255) NOT NULL default '',
  `Var14` varchar(255) NOT NULL default '',
  `Var15` varchar(255) NOT NULL default '',
  `Var16` varchar(255) NOT NULL default '',
  `Var17` varchar(255) NOT NULL default '',
  `Var18` varchar(255) NOT NULL default '',
  `Var19` varchar(255) NOT NULL default '',
  `Var20` varchar(255) NOT NULL default '',
  `Var21` varchar(255) NOT NULL default '',
  `Var22` varchar(255) NOT NULL default '',
  `Var23` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `gallarific_users` (
  `userid` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `usertype` enum('superuser','normaluser') NOT NULL default 'superuser',
  `firstname` varchar(100) NOT NULL default '',
  `lastname` varchar(100) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `datejoined` int(11) NOT NULL default '0',
  `website` varchar(255) NOT NULL default '',
  `issuperuser` tinyint(4) NOT NULL default '0',
  `photo` varchar(100) NOT NULL default '',
  `joincode` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`userid`)
);

CREATE TABLE IF NOT EXISTS `gallarific_settings` (
  `settings_id` int(11) NOT NULL auto_increment,
  `settings_name` varchar(100) NOT NULL default '',
  `settings_value` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`settings_id`)
);

