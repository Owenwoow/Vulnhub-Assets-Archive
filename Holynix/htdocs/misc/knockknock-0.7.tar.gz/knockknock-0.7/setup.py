import sys, os, shutil
from distutils.core import setup, Extension

shutil.copyfile("knockknock-daemon.py", "knockknock/knockknock-daemon")
shutil.copyfile("knockknock-genprofile.py", "knockknock/knockknock-genprofile")
shutil.copyfile("knockknock-proxy.py", "knockknock/knockknock-proxy")
shutil.copyfile("knockknock.py", "knockknock/knockknock")


setup  (name        = 'knockknock',
        version     = '0.6',
        description = 'A cryptographic single-packet port-knocker.',
        author = 'Moxie Marlinspike',
        author_email = 'moxie@thoughtcrime.org',
        url = 'http://www.thoughtcrime.org/software/knockknock/',
        license = 'GPL',
        packages  = ["knockknock", "knockknock.proxy"],
#        package_dir = {'knockknock' : 'knockknock/'},
        scripts = ['knockknock/knockknock-daemon', 'knockknock/knockknock-genprofile', 'knockknock/knockknock-proxy', 'knockknock/knockknock'],
        data_files = [('share/knockknock', ['README', 'INSTALL', 'COPYING']),
                      ('/etc/knockknock.d/', ['config'])]
       )

print "Cleaning up..."

try:
    removeall("build/")
    os.rmdir("build/")
except:
    pass

try:
    os.remove("knockknock/knockknock-proxy")
    os.remove("knockknock/knockknock-daemon")
    os.remove("knockknock/knockknock-genprofile")
    os.remove("knockknock/knockknock")

except:
    pass

def capture(cmd):
    return os.popen(cmd).read().strip()

def removeall(path):
	if not os.path.isdir(path):
		return

	files=os.listdir(path)

	for x in files:
		fullpath=os.path.join(path, x)
		if os.path.isfile(fullpath):
			f=os.remove
			rmgeneric(fullpath, f)
		elif os.path.isdir(fullpath):
			removeall(fullpath)
			f=os.rmdir
			rmgeneric(fullpath, f)

def rmgeneric(path, __func__):
	try:
		__func__(path)
	except OSError, (errno, strerror):
		pass
